opt/etl/prd/etl/APP/RPT/U_RELAY42_TX_GEN_RPT/bin> cat u_relay42_gen_rpt0010.pl
#####################################################
#   $Header: /CVSROOT/SmarTone-Vodafone/Code/ETL/Template/b_JobName0010.pl,v 1.2 2005/11/16 08:35:06 MichaelNg Exp $
#   Purpose:
#
#
######################################################
#*#my $ETLVAR = $ENV{"AUTO_ETLVAR"};require $ETLVAR;
my $ETLVAR =  "/opt/etl/prd/etl/APP/RPT/U_RELAY42_TX_GEN_RPT/bin/master_dev.pl";
require $ETLVAR;

my $MASTER_TABLE = ""; #Please input the final target ADW table name here


my $DSSVR,$DSUSR,$DSPWD,$DSPROJECT,$DSJOBNAME,$ulog,$TABLEDB,$REPFILENAME,$TDSVR,$TDUSR,$TDPWD,$ERRTXDATE,$OUTPUT_FILE_PATH,$ENV,$OUTPUTFILENAME;
my $FTP_HOST,$FTP_USERNAME,$FTP_PASSWORD,$FTP_DEST_PATH,$FTP_LOCAL_PATH,$FTP_FILENAME ,$COMPLETEFILE_NAME,$FTP_TO_COMPLETEFILE;



###YYY
sub runSQLPLUS{
    my $rc = open(SQLPLUS, "| sqlplus /\@${etlvar::TDDSN}");
    unless ($rc){
        print "Cound not invoke SQLPLUS command\n";
        return -1;
    }

    print SQLPLUS<<ENDOFINPUT;
#*#
whenever sqlerror exit 2;
set serveroutput on;
set sqlblanklines on;
set autocommit 1;
set timing on;
set echo on;
set sqlnumber off;
set define off;
ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';
#*#

#*#${etlvar::LOGON_TD}
#*#${etlvar::SET_MAXERR}
#*#${etlvar::SET_ERRLVL_1}
#*#${etlvar::SET_ERRLVL_2}
--Please type your SQL statement here
alter session force parallel query;
alter session enable parallel dml;

#*#execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL2(P_schema_tbl_name=>'${etlvar::TMPDB}.U_RELAY42_GEN_RPT');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL2(P_schema_tbl_name=>'${etlvar::TMPDB}.U_RELAY42_TX_GEN_RPT');

#*#INSERT /*+ APPEND parallel(64) */ INTO ${etlvar::TMPDB}.U_RELAY42_GEN_RPT
INSERT /*+ APPEND parallel(64) */ INTO ${etlvar::TMPDB}.U_RELAY42_TX_GEN_RPT
(
  Acct_Subr_Num_h
,Acct_Subr_Num_e
,Acct_Num_h
,Acct_Num_e
,Subr_Num_h
,Subr_Num_e
,HKID_BR_h
,HKID_BR_e
,Comm_Email_h
,Comm_Email_e
,Comm_Lang
,BILL_Email_h
,BILL_Email_e
,Customer_Type
,Line_Status
,Masked_Flg
,Payment_Method
,PP_Tier
,Loginnow_Status
,Subr_Plan_Name
,Plan_Cat
,Max_LD_Expiry_Date
,RDDP_Flg
,VWE_Flg
,Traval_Past_6mths
,Create_Ts
,Refresh_Ts
,BLACK_LIST_CUST_WRITHOFF_FLG
,BLACK_LIST_CUSTOMER_FLG
,DM_CONSENT_DERIVED_FLG
,REJECT_ALL_COMM_FLG
,D_FREEZE_FLG
,D_FREEZE_FLG_EMAIL
,D_FREEZE_FLG_SMS
,D_LIMITED_CONTACT
,D_LIMITED_CONTACT_EMAIL
,D_LIMITED_CONTACT_SMS
,SUPRT_MMS_FLG
,EMAIL_INTERNET_STUFF_EMAIL_FLG
,EMAIL_INTERNET_STUFF_SMS_FLG
,FUN_STUFF_EMAIL_FLG
,FUN_STUFF_SMS_FLG
,NEWS_FINANCE_INVEST_EMAIL_FLG
,NEWS_FINANCE_INVEST_SMS_FLG
,SENSITIVE_SUBJECT_EMAIL_FLG
,SENSITIVE_SUBJECT_SMS_FLG
,SPECIAL_OFFER_EMAIL_FLG
,SPECIAL_OFFER_SMS_FLG
)
select
 a.Acct_Subr_Num_h
,a.Acct_Subr_Num_e
,a.Acct_Num_h
,a.Acct_Num_e
,a.Subr_Num_h
,a.Subr_Num_e
,a.HKID_BR_h
,a.HKID_BR_e
,a.Comm_Email_h
,a.Comm_Email_e
,a.Comm_Lang
,a.BILL_Email_h
,a.BILL_Email_e
,a.Customer_Type
,a.Line_Status
,a.Masked_FLG
,a.Payment_Method
,a.PP_Tier
,a.Loginnow_Status
,a.Subr_Plan_Name
,a.Plan_Cat
,TO_CHAR(a.Max_LD_Expiry_Date , 'YYYY-MM-DD')
,a.RDDP_Flg
,a.VWE_Flg
,a.Traval_Past_6mths
,a.Create_Ts
,a.Refresh_Ts
,a.BLACK_LIST_CUST_WRITHOFF_FLG
,a.BLACK_LIST_CUSTOMER_FLG
,a.DM_CONSENT_DERIVED_FLG
,a.REJECT_ALL_COMM_FLG
,a.D_FREEZE_FLG
,a.D_FREEZE_FLG_EMAIL
,a.D_FREEZE_FLG_SMS
,a.D_LIMITED_CONTACT
,a.D_LIMITED_CONTACT_EMAIL
,a.D_LIMITED_CONTACT_SMS
,a.SUPRT_MMS_FLG
,a.EMAIL_INTERNET_STUFF_EMAIL_FLG
,a.EMAIL_INTERNET_STUFF_SMS_FLG
,a.FUN_STUFF_EMAIL_FLG
,a.FUN_STUFF_SMS_FLG
,a.NEWS_FINANCE_INVEST_EMAIL_FLG
,a.NEWS_FINANCE_INVEST_SMS_FLG
,a.SENSITIVE_SUBJECT_EMAIL_FLG
,a.SENSITIVE_SUBJECT_SMS_FLG
,a.SPECIAL_OFFER_EMAIL_FLG
,a.SPECIAL_OFFER_SMS_FLG
from
 ${etlvar::ADWDB}.RELAY42_TX_LIST a
#${etlvar::ADWDB}.RELAY42_LIST a
left outer join
#*#${etlvar::TMPDB}.B_RELAY42_LIST_001_TMP b
${etlvar::TMPDB}.B_RELAY42_TX_LIST_001_TMP b
on a.Acct_Subr_Num_h=b.Acct_Subr_Num_h
and a.Acct_Num_h=b.Acct_Num_h
and a.Subr_Num_h=b.Subr_Num_h
and a.HKID_BR_h=b.HKID_BR_h
and a.Comm_Email_h=b.Comm_Email_h
and a.Comm_Lang=b.Comm_Lang
and a.BILL_Email_h=b.BILL_Email_h
and a.Customer_Type=b.Customer_Type
and a.Line_Status=b.Line_Status
and a.Masked_FLG=b.Masked_FLG
and a.Payment_Method=b.Payment_Method
and a.PP_Tier=b.PP_Tier
and a.Loginnow_Status=b.Loginnow_Status
and a.Subr_Plan_Name=b.Subr_Plan_Name
and a.Plan_Cat=b.Plan_Cat
and a.Max_LD_Expiry_Date=b.Max_LD_Expiry_Date
and a.RDDP_Flg=b.RDDP_Flg
and a.VWE_Flg=b.VWE_Flg
and a.Traval_Past_6mths=b.Traval_Past_6mths
and a.BLACK_LIST_CUST_WRITHOFF_FLG=b.BLACK_LIST_CUST_WRITHOFF_FLG
and a.BLACK_LIST_CUSTOMER_FLG=b.BLACK_LIST_CUSTOMER_FLG
and a.DM_CONSENT_DERIVED_FLG=b.DM_CONSENT_DERIVED_FLG
and a.REJECT_ALL_COMM_FLG=b.REJECT_ALL_COMM_FLG
and a.D_FREEZE_FLG=b.D_FREEZE_FLG
and a.D_FREEZE_FLG_EMAIL=b.D_FREEZE_FLG_EMAIL
and a.D_FREEZE_FLG_SMS=b.D_FREEZE_FLG_SMS
and a.D_LIMITED_CONTACT=b.D_LIMITED_CONTACT
and a.D_LIMITED_CONTACT_EMAIL=b.D_LIMITED_CONTACT_EMAIL
and a.D_LIMITED_CONTACT_SMS=b.D_LIMITED_CONTACT_SMS
and a.SUPRT_MMS_FLG=b.SUPRT_MMS_FLG
and a.EMAIL_INTERNET_STUFF_EMAIL_FLG=b.EMAIL_INTERNET_STUFF_EMAIL_FLG
and a.EMAIL_INTERNET_STUFF_SMS_FLG=b.EMAIL_INTERNET_STUFF_SMS_FLG
and a.FUN_STUFF_EMAIL_FLG=b.FUN_STUFF_EMAIL_FLG
and a.FUN_STUFF_SMS_FLG=b.FUN_STUFF_SMS_FLG
and a.NEWS_FINANCE_INVEST_EMAIL_FLG=b.NEWS_FINANCE_INVEST_EMAIL_FLG
and a.NEWS_FINANCE_INVEST_SMS_FLG=b.NEWS_FINANCE_INVEST_SMS_FLG
and a.SENSITIVE_SUBJECT_EMAIL_FLG=b.SENSITIVE_SUBJECT_EMAIL_FLG
and a.SENSITIVE_SUBJECT_SMS_FLG=b.SENSITIVE_SUBJECT_SMS_FLG
and a.SPECIAL_OFFER_EMAIL_FLG=b.SPECIAL_OFFER_EMAIL_FLG
and a.SPECIAL_OFFER_SMS_FLG=b.SPECIAL_OFFER_SMS_FLG
where b.Subr_Num_h is null
;

commit;

ENDOFINPUT

    close(SQLPLUS);
    my $RET_CODE = $? >> 8;
    if ($RET_CODE != 0){
        return 1;
    }else{
        return 0;
    }
}


###YYY
sub initParam{

    # PARAMETERS -- For Datastage File Export
    $DSSVR = "${etlvar::DSSVR}";#*#$DSSVR = $ENV{"DSSVR"};
    $DSUSR = "${etlvar::DSUSR}";
    $DSPWD = "${etlvar::DSPWD}";
    $DSPROJECT = "${etlvar::DSPROJECT}";#*#$ENV{"DSPROJECT"};
    $DSJOBNAME = "${etlvar::ETLJOBNAME}";
    $ulog = "${etlvar::ulog}";#*#$ulog = q(2>&1);

    $TABLEDB = "${etlvar::TMPDB}";#*#$TMPDB = "MIG_ADW";
    #$TABLEDB = "MIG_ADW";
    $REPFILENAME = "${etlvar::ETLJOBNAME}";
    $TDSVR = "${etlvar::TDSVR}";#*#$ENV{"TDSVR"};
    $TDUSR = "${etlvar::TDUSR}";
    $TDPWD = "${etlvar::TDPWD}";

    # Get ERRTXDATE
    my ($esec,$emin,$ehour,$emday,$emon,$eyear,$ewday,$eyday,$eisdst) = localtime(time());
    $eyear += 1900;
    $emon = sprintf("%02d", $emon+1);
    $emday = sprintf("%02d", $emday);
    $ehour = sprintf("%02d",$ehour);
    $emin = sprintf("%02d",$emin);
    $ERRTXDATE = "${emon}${emday}${ehour}";
    
    $OUTPUT_FILE_PATH = "${etlvar::ETL_TMP_DIR_DS}";#*#${ETLPATH}/tmp
    $ENV = $ENV{"ETL_ENV"};

    # Get LASTMONTH
    #my ($lsec,$lmin,$lhour,$lmday,$lmon,$lyear,$lwday,$lyday,$lisdst) = localtime(time());
    my $yyyymm, $lyear, $lmon;

    $yyyymm = "${etlvar::TXMONTH}";
    $lyear = substr($yyyymm,0,4);
    $lmon = substr($yyyymm,4,2);
    $lmon -= 1;

    if ($lmon == 0){

            $lmon = 12;
                $lyear -= 1;
                $lmon = sprintf("%02d", $lmon);
        }
        else{

        $lmon = sprintf("%02d", $lmon);
        }

            use Date::Manip;

    #*#
    my $SYS_DATE=`date +%Y%m%d`;
    
    #my $FILE_DATE = &UnixDate(${etlvar::TXDATE}, "%Y%m%d");
    
    #*#
    my $PROCESS_DATE = &UnixDate($SYS_DATE, "%Y%m%d");
   
   #*#
    #my $PROCESS_DATE = &UnixDate(${etlvar::TXDATE}, "%Y%m%d");
    #*#
    #my $delete_PROCESS_DATE = &UnixDate(DateCalc("${etlvar::TXDATE}","- 5 days",\$err), "%Y%m%d");
    #*#
    my $delete_PROCESS_DATE = &UnixDate(DateCalc($SYS_DATE,"- 5 days",\$err), "%Y%m%d");
    # ------------------------------------------------------------------#
    #  Please define the parameters for this job below.                 #
    # ------------------------------------------------------------------#

    if ($ENV eq "DEV"){

            ##  DEVELOPMENT  ##
		
        my $FILE_PATH = "/opt/etl/output/RPT/${etlvar::ETLJOBNAME}/";
        
     
        my $FILE_NAME = "unload_relay42_list.dat.$PROCESS_DATE";
        
       
        my $COMPLETE_NAME = "unload_relay42_list.dat.$PROCESS_DATE.complete";

        $OUTPUTFILENAME = "${FILE_PATH}${FILE_NAME}";
        $COMPLETEFILE_NAME = "${FILE_PATH}${COMPLETE_NAME}";

        # PUT action
        $FTP_TO_HOST = "";
        $FTP_TO_USERNAME = "";
        $FTP_TO_PASSWORD = "";
        $FTP_TO_DEST_PATH = "";
        $FTP_TO_LOCAL_PATH = "${FILE_PATH}";
        $FTP_TO_FILENAME = "${FILE_NAME}";

        # GET action
        $FTP_FROM_HOST = "${DSSVR}";
        $FTP_FROM_USERNAME = "${DSUSR}";
        $FTP_FROM_PASSWORD = "${DSPWD}";
        $FTP_FROM_DEST_PATH = "${FILE_PATH}";
        $FTP_FROM_LOCAL_PATH = "${FILE_PATH}";
        $FTP_FROM_FILENAME = "${FILE_NAME}";

    }
    else
    {
        ##  PRODUCTION  ##

        $FILE_PATH = "/opt/etl/output/RPT/${etlvar::ETLJOBNAME}/";
        my $FILE_NAME = "unload_relay42_list.dat.$PROCESS_DATE";
         $FILE_NAME_2 = "unload_relay42_list_$PROCESS_DATE.csv";
         $FILE_NAME_3 = "unload_relay42_list_$PROCESS_DATE.csv.gpg";
         
        my $COMPLETE_NAME   = "unload_relay42_list.dat.$PROCESS_DATE.complete";
         $COMPLETE_NAME_2 = "unload_relay42_list_$PROCESS_DATE.complete";
         
        $OUTPUTFILENAME = "${FILE_PATH}${FILE_NAME}";
        $OUTPUTFILENAME_2 = "${FILE_PATH}${FILE_NAME_2}";
        $COMPLETEFILE_NAME = "${FILE_PATH}${COMPLETE_NAME}";
        $COMPLETEFILE_NAME_2 = "${FILE_PATH}${COMPLETE_NAME_2}";

            # PUT action
        $FTP_TO_HOST = "appftp03";
        $FTP_TO_USERNAME = "relay42desftp";
        $FTP_TO_PASSWORD = "";
        $FTP_TO_DEST_PATH = "output";
        $FTP_TO_LOCAL_PATH = "${FILE_PATH}";
        $FTP_TO_FILENAME = "${FILE_NAME_2}";
        $FTP_TO_COMPLETEFILE = "${COMPLETE_NAME_2}";

        }
        
        	
        
        #*#
        my $FILE_PATH = "/opt/etl/prd/etl/APP/RPT/U_RELAY42_TX_GEN_RPT/bin/";
        my $FILE_NAME = "unload_relay42_TX_list.dat.$PROCESS_DATE";
        my $COMPLETE_NAME = "unload_relay42_TX_list.dat.$PROCESS_DATE.complete";
        $OUTPUTFILENAME = "${FILE_PATH}${FILE_NAME}";
        $COMPLETEFILE_NAME = "${FILE_PATH}${COMPLETE_NAME}";
        
        $FILE_NAME_2 = "unload_relay42_TX_list_$PROCESS_DATE.csv";
        $FILE_NAME_3 = "unload_relay42_TX_list_$PROCESS_DATE.csv.gpg";
        my $COMPLETE_NAME   = "unload_relay42_TX_list.dat.$PROCESS_DATE.complete";
        $COMPLETE_NAME_2 = "unload_relay42_TX_list_$PROCESS_DATE.complete";  
        
        $OUTPUTFILENAME = "${FILE_PATH}${FILE_NAME}"; 
        $OUTPUTFILENAME_2 = "${FILE_PATH}${FILE_NAME_2}";  
		
        $COMPLETEFILE_NAME = "${FILE_PATH}${COMPLETE_NAME}";
        $COMPLETEFILE_NAME_2 = "${FILE_PATH}${COMPLETE_NAME_2}"; 
        
        $FTP_TO_HOST = "appftp03";
        $FTP_TO_USERNAME = "relay42desftp";
        $FTP_TO_PASSWORD = "";
        $FTP_TO_DEST_PATH = "output";
        $FTP_TO_LOCAL_PATH = "${FILE_PATH}";
        $FTP_TO_FILENAME = "${FILE_NAME_2}";
        $FTP_TO_COMPLETEFILE = "${COMPLETE_NAME_2}";
		#*#

        #print("rm -f ${FTP_TO_DEST_PATH}unload_bp_gprs_summ.dat.${delete_PROCESS_DATE)* \n");
    #system("rm -f ${FTP_TO_DEST_PATH}unload_bp_gprs_summ.dat.${delete_PROCESS_DATE)*");
        #print("rm -f ${FTP_TO_LOCAL_PATH}unload_bp_gprs_summ.dat* \n");
    #system("rm -f ${FTP_TO_LOCAL_PATH}unload_bp_gprs_summ.dat*");

}
# RESET  DATASTAGE  JOB  &  RUN
###YYY
sub runDataStageExport{


#    print("dsjob -run -mode RESET ${DSPROJECT} ${DSJOBNAME} ${ulog}\n\n");
#    print("dsjob -run -mode NORMAL -param OUTPUTFILENAME=${OUTPUTFILENAME} -param TDDB=${TABLEDB} -param TDTABLE=${TABLEDB}.${DSJOBNAME} -param REPFILENAME=${REPFILENAME} -param TDSVR=${TDSVR} -param TDUSR=${TDUSR} -param TDPWD=${TDPWD} -param OUTPUT_FILE_PATH=${OUTPUT_FILE_PATH} -param ERRTXDATE=${ERRTXDATE} -param ENV=${ENV} -wait -jobstatus ${DSPROJECT} ${DSJOBNAME} ${ulog}\n\n");


    my $ds_ret = 0;


    $ds_ret = system("dsjob -run -mode RESET ${DSPROJECT} ${DSJOBNAME} ${ulog}");
    sleep(10);
    $ds_ret = system("dsjob -run -mode NORMAL -param OUTPUTFILENAME=${OUTPUTFILENAME} -param TDDB=${TABLEDB} -param TDTABLE=${TABLEDB}.${DSJOBNAME} -param REPFILENAME=${REPFILENAME} -param TDSVR=${TDSVR} -param TDUSR=${TDUSR} -param TDPWD=${TDPWD} -param OUTPUT_FILE_PATH=${OUTPUT_FILE_PATH} -param ERRTXDATE=${ERRTXDATE} -param ENV=${ENV} -wait -jobstatus ${DSPROJECT} ${DSJOBNAME} ${ulog}");




    if ($ds_ret == 256)
    {
        print("\n\n\n#####################################\n");
        print("#  DataStage File Export complete\n");
        print("#####################################\n\n");

        return 0;
    }
    elsif ($ds_ret == 512)
    {

        print("\n\n\n#####################################\n");
        print("#  DataStage File Export complete (with warnings)\n");
        print("#####################################\n\n");

        return 0;
    }
    else
    {
        print("\n\n\n#####################################\n");
        print("#  DataStage File Export failed:\n");
        print("#  ${DSPROJECT} ${DSJOBNAME}\n");
        print("#####################################\n\n");

        return 1;
    }
}

###YYY
sub convert_to_newfile{

  my $perl_ret = 0;


    $perl_ret = system("perl /opt/etl/prd/etl/APP/RPT/U_RELAY42_GEN_RPT/bin/RELAY42_GEN_FILE2.pl $OUTPUTFILENAME $OUTPUTFILENAME_2");
     print("perl /opt/etl/prd/etl/APP/RPT/U_RELAY42_GEN_RPT/bin/RELAY42_GEN_FILE2.pl $OUTPUTFILENAME $OUTPUTFILENAME_2");
    if ($perl_ret==0) {
        print("\n convert to $OUTPUTFILENAME_2 Completed ");
    } else {
        print("\n convert to $OUTPUTFILENAME_2 Failed ");
        exit(1);
    }
        return perl_ret;

}


###YYY
sub processFile{

    print("\n\n\n");
    print("#####################################\n");
    print("#  PROCESSING FILES                  \n");
    print("#####################################\n");

    my $process_ret = 0;
##  REMOVE ',' FROM OUTPUT FILE
    my @file_list_1;

    # push(@file_list, "$OUTPUT_FILE_PATH/$OUTPUT_FILE_NAME_1");
    # @file_list = <$OUTPUT_FILE_PATH/*.dat>;

      @file_list_1 = <${FILE_PATH}${FILE_NAME_2}>;
print("Done1 $OUTPUTFILENAME_2\n");
    foreach $file (@file_list_1)
    {
        if ($process_ret == 0) {
print("Done2 $file\n");
            #$process_return = system("sed '1,2d' ${file} > ${file}.TMP");
            if ($process_ret == 0) {
                    $process_ret = system("echo 'id|Acct_Subr_Num_hs,id|Acct_Subr_Num_e,id|Acct_Num_hs,id|Acct_Num_e,id|Subr_Num_hs,id|Subr_Num_h,id|Subr_Num_e,id|HKID_BR_hs,id|HKID_BR_e,id|Comm_Email_hs,id|Comm_Email_h,id|Comm_Email_e,customerData|Comm_Lang,id|BILL_Email_hs,id|BILL_Email_h,id|BILL_Email_e,customerData|Customer_Type,productData|Line_Status,productData|Masked_Flg,customerData|Payment_Method,customerData|PP_Tier,customerData|Loginnow_Status,customerData|Subr_Plan_Name,customerData|Plan_Cat,customerData|Max_LD_Expiry_Date,customerData|RDDP_Flg,customerData|VWE_Flg,customerData|Traval_Past_6mths,customerData|Black_List_Customer,customerData|Black_List_Cust_excl_write-off_settled,customerData|Direct_Marketing_Consent_Derived,customerData|Reject_All_Communication,customerData|Freezing_Period_Flag,customerData|Freezing_Period_Flag_Email,customerData|Freezing_Period_Flag_SMS,customerData|Limited_Contact_Flag,customerData|Limited_Contact_Flag_Email,customerData|Limited_Contact_Flag_SMS,customerData|Current_Handset-Support_MMS,customerData|Communication_and_Internet_via_Email,customerData|Communication_and_Internet_via_Handset,customerData|Fun_stuff_via_Email,customerData|Fun_stuff_via_Handset,customerData|News_and_finance_and_investment_via_Email,customerData|News_and_finance_and_investment_via_Handset,customerData|Retention_Offers_via_Email,customerData|Retention_Offers_via_Handset,customerData|Special_Offers_via_Email,customerData|Special_Offers_via_Handset' >> $file.TMP");
                    }
print("Done3 $file.TMP\n");
            if ($process_ret == 0) {
                                $process_ret = system("cat ${file} >> ${file}.TMP");
                        }

            if ($process_ret == 0) {
                                $process_ret = system("mv -f ${file}.TMP ${file}");
                        }

                        if ($process_ret == 0) {
                                print("Done \n");
                        }
                        else {
                                print("Failed! \n");
                        }
        }
    }
    return $process_ret;
}



###YYY
sub check_All_Files{

    ($OUTPUT_FILE_NAME) = @_;
    my $file_status = 0;
    my $return_cd = 0;
    my $OLD_FILENAME= "${FILE_PATH}${OUTPUT_FILE_NAME}.gpg";
    print("\nChecking Old encrypted File  --->  ${OUTPUT_FILE_NAME}  ......  ");
    if (-e $OLD_FILENAME) {
        #Delete the old gpg file.
     system("rm ${OLD_FILENAME}");
    }
    print("\nOld encrypted File Removed --->  ${OUTPUT_FILE_NAME}  ......  ");

    print("\nChecking File  --->  ${OUTPUT_FILE_NAME}  ......  ");

    open (FILE, "${FILE_PATH}${OUTPUT_FILE_NAME}") || die "\nCan not open file:  ${FILE_PATH}${OUTPUT_FILE_NAME}"."\n\n$!";

    close(FILE);

    print("done.\n");
    $OUTPUT_FILE="${FILE_PATH}${OUTPUT_FILE_NAME}";
    if (-e $OUTPUT_FILE){
        #$return_cd=system("echo 'dw888' | gpg --no-tty --passphrase-fd 0 -c ${OUTPUT_FILE_PATH}/${OUTPUT_FILE_NAME}");
                $return_cd=system("echo '+YuU^(_J9.vU[Mnn' | gpg  --batch --no-tty  --passphrase-fd 0 -c ${FILE_PATH}${OUTPUT_FILE_NAME}");

    };

    if ($return_cd==0) {
        print("\n File Encrypted --->  ${OUTPUT_FILE_NAME}.gpg  ......  ");
    } else {
        print("\n File Encrypted Failed--->  ${OUTPUT_FILE_NAME}.gpg  ......  ");
        exit(1);
    }
    return $file_status;
}




# Send the file to user
###yyy
sub uploadFile{
    print("\n\n\n");
    print("#########################################\n");
    print("#  UPLOAD FILE TO SERVER ($FTP_TO_HOST)  \n");
    print("#########################################\n");

    my $process_ret = 0;
    my $file_list_y1 = <$FILE_PATH$FILE_NAME_3>;

    print("UPLOAD FILE TO SFTP SERVER: $file_list_y1 \n");
    $process_ret = system("/opt/etl/prd/etl/APP/RPT/U_RELAY42_GEN_RPT/bin/sftp.exp ${file_list_y1}");

    return $process_ret;
}


# Send the file to user

sub uploadFile_2{
   print("\n\n\n#####################################\n");
    print("#  SEND FILE TO USER\n");
    print("#####################################\n");


    use Net::FTPSSL;

    if (${etlvar::ENABLE_FTP} eq "N") {
      print ("FTP is disabled in non-production environment!\n");
      return 0;
    }


    my $ftp_return = 0;


    ##  CONNECT TO HOST
    $ftp = Net::FTPSSL->new(${FTP_TO_HOST}, Port=>${FTP_TO_PORT},Encryption => 'E',Debug => 1)
     or die "Cannot connect to ${FTP_TO_HOST}: $@";

    ##  LOGIN
    $ftp->login("$FTP_TO_USERNAME","$FTP_TO_PASSWORD")
          or die "Cannot login ", $ftp->message;

    ##  CHANGE REMOTE DIRECTORY
    $ftp->cwd(${FTP_TO_DEST_PATH})
    or die "Cannot change working directory ", $ftp->message;

    ##  CHANGE TRANSFER MODE  ( ascii / binary )
    $ftp->binary
    or die "Cannot change transfer mode ", $ftp->message;

    ##  TRANSFER FILES
    @file_list = <$COMPLETEFILE_NAME_2>;

    foreach $file (@file_list)
   {
    print("Transfer $file ... ");

    $ftp->put($file)
    or die "Failed! ", $ftp->message;

    print("Done \n");
  }


  ##  DISCONNECT
  $ftp->quit();


  return $ftp_return;
}




###yyy
sub uploadFile_complete{
    print("\n\n\n");
    print("#########################################\n");
    print("#  UPLOAD FILE TO SERVER ($FTP_TO_HOST)  \n");
    print("#########################################\n");

    my $process_ret = 0;
    my $file_list_y1 = <$FILE_PATH$COMPLETE_NAME_2>;

    print("UPLOAD FILE TO SFTP SERVER: $file_list_y1 \n");
    $process_ret = system("/opt/etl/prd/etl/APP/RPT/U_RELAY42_GEN_RPT/bin/sftp.exp ${file_list_y1}");

    return $process_ret;
}





#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_cust_info0010.pl adw_b_cust_info_20051010.dir\n");
    exit(1);
}

#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);

my $ret = runSQLPLUS();
initParam();
# RESET  DATASTAGE  JOB  &  RUN
if ($ret == 0)
    {
           $ret = runDataStageExport();
     }



if ($ret == 0)
    {
     $ret = convert_to_newfile();
     }

 if ($ret == 0)
    {
      $ret = processFile();
     }
      if ($ret == 0)
    {

    $ret = check_All_Files("${FILE_NAME_2}");
    }
     if ($ret == 0)
    {
         $ret = system("touch $COMPLETEFILE_NAME_2");
    }


# SEND FILE TO USER
print("\n\n\n");
print("#########################################\n");
print("#  COPY FILES TO $FTP_TO_DEST_PATH  \n");
print("#########################################\n");

if ($ret == 0)
    {
            $ret = uploadFile();
    }

if ($ret == 0)
    {
            $ret = uploadFile_complete();
    }

my $post = etlvar::postProcess();
exit($ret);