/opt/etl/prd/etl/APP/RBD/D_RBD_CAP_AMORT_RPT_CRBK/bin> cat d_rbd_cap_amort_rpt_crbk0010.pl
######################################################
#   $Header: /CVSROOT/SmarTone-Vodafone/Code/ETL/Template/d_JobName0010.pl,v 1.2 2005/11/14 14:44:04 MichaelNg Exp $
#   Purpose:
#   
#
######################################################

use Date::Manip;

my $ETLVAR = $ENV{"AUTO_ETLVAR"};require $ETLVAR;


#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl d_cust_info001.pl adw_d_cust_info_20051010.dir\n");
    exit(1);
}

my $last_month;
my $MASTER_TABLE = ""; #Please input the final target ADW table name here
#my $LOADING_TABLE_DB = "$etlvar::TMPDB"; #Please use the variable name defined in the etlvar
my $LOADING_TABLE_DB = "PRD_TMP"; #Please use the variable name defined in the etlvar
$etlvar::DS_MLOAD = "N";  # Y - indicate a multiload job and N - indicate a fastload job

sub initParam{
        $last_month = &UnixDate("${etlvar::TXDATE}", "%Y-%m")."-01";
}

sub runSQLPLUS{
    my $rc = open(SQLPLUS, "| sqlplus /\@${etlvar::TDDSN}");
    unless ($rc){
        print "Cound not invoke SQLPLUS command\n";
        return -1;
    }
print SQLPLUS <<ENDOFINPUT;
        ${etlvar::LOGON_TD}
        ${etlvar::SET_MAXERR}
        ${etlvar::SET_ERRLVL_1}
        ${etlvar::SET_ERRLVL_2}

--Please type your SQL statement here
--EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.D_RETENTION_COMM_STAFF_T');

--delete from ${etlvar::TMPDB}.ETL_JOB where LAST_TXDATE=date'$last_month';

ENDOFINPUT
        close(SQLPLUS);
    my $RET_CODE = $? >> 8;
    if ($RET_CODE != 0){
        return 1;
    }else{
        return 0;
    }



}


#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);

etlvar::genFirstDayOfMonth($etlvar::TXDATE);
initParam();


my $ret = etlvar::runDataStageJob($LOADING_TABLE_DB, $MASTER_TABLE);


my $post = etlvar::postProcess($MASTER_TABLE);
 
 
exit($ret);
/opt/etl/prd/etl/APP/RBD/D_RBD_CAP_AMORT_RPT_CRBK/bin>      cd /home/adwbat/
/home/adwbat> mkdir s_to_o
/home/adwbat> cd s_to_o
/home/adwbat/s_to_o> touch test.txt
/home/adwbat/s_to_o> vi test.txt 
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
~
"test.txt" 1L, 16C written                                                                     
/home/adwbat/s_to_o> cd ..
/home/adwbat> cd tmp
/home/adwbat/tmp> ls -l
total 60992
-rw-r--r--  1 adwbat dstage    37795 Nov  6  2017 1.dat
-rw-r--r--  1 adwbat dstage  2517193 Jun 30  2017 2.dat
-rw-r--r--  1 adwbat dstage  1667344 Oct 13  2016 awrrpt_1_10575_10576.html
-rw-r--r--  1 adwbat dstage  2050980 Oct 13  2016 awrrpt_1_10576_10577.html
-rw-r--r--  1 adwbat dstage   309248 Dec 24  2018 bm_comm_20161201.xls
drwxr-xr-x  3 adwbat dstage     4096 Jan 30  2018 B_RELOAD_P_MKT
drwxr-xr-x  2 adwbat dstage     4096 Jul 30 11:09 carmen
drwx------  4 adwbat dstage    16384 Jul 15  2016 ch
drwx------  7 adwbat dstage     4096 Jun 20  2018 CJ
-rwx------  1 adwbat dstage    21076 Feb 14  2016 cogstartup.xml.gz
drwx------  3 adwbat dstage     4096 Jul 14  2016 compare
drwx------ 15 adwbat dstage     4096 Apr 11 14:48 DASH
drwx------  5 adwbat dstage     4096 May 28  2016 dash_hl
drwx------  4 adwbat dstage    16384 Dec  7  2016 Dickey
-rwxr-xr-x  1 adwbat dstage      890 Jul 11  2016 D_LDCODE.ksh
-rwxr-xr-x  1 adwbat dstage     1020 Jul 11  2016 D_LDCODE.pl
-rwx------  1 adwbat dstage 32438237 Apr  5  2016 DS_11_2.xml.gz
-rwx------  1 adwbat dstage  6375915 Mar 30  2016 DS_lt1.TMP
-rwx------  1 adwbat dstage    46709 Apr  6  2016 DS_PATH2.xml.gz
-rwx------  1 adwbat dstage    44203 Apr  6  2016 DS_PATH.xml.gz
drwxr-xr-x  2 adwbat dstage     4096 Jul 26  2018 DS_TEST
-rw-r--r--  1 adwbat dstage   800522 Jun 30  2017 ec_courier_case_30.gpg
-rwx------  1 adwbat dstage   228958 May 24  2016 error.xml.gz
-rw-r--r--  1 adwbat dstage    78487 Aug  1 23:00 gather_etl_stats.sql
-rw-r--r--  1 adwbat dstage    34801 Nov 21  2016 gather_etl_stats.sql.bak
drwx------  9 adwbat dstage     4096 Jul 26  2016 hw
drwx------  2 adwbat dstage     4096 Jun 26  2016 hy
drwx------ 19 adwbat dstage     4096 Aug  2 17:00 irene
drwx------  3 adwbat dstage     4096 Apr 25  2016 java_Kelvin
drwx------  3 adwbat dstage     4096 Sep 25  2015 jmak
drwx------  7 adwbat dstage     4096 Nov 27  2017 joe
drwx------ 19 adwbat dstage    12288 Apr 13  2018 kelvin
drwx------  2 adwbat dstage     4096 Dec  7  2016 kennyw
drwxr-xr-x  2 adwbat dstage     4096 Apr 28  2017 kevin
-rwx------  1 adwbat dstage    49917 Apr  1  2016 len.xml.gz
-rw-r--r--  1 adwbat dstage   607940 Jan 19  2017 mocdr_201612.zip
drwx------  3 adwbat dstage     4096 Jul  5  2016 penchan
-rw-r--r--  1 adwbat dstage  6641152 May 19  2017 PlanVDRSRate_1703.xls
-rw-r--r--  1 adwbat dstage  6151680 May 19  2017 PlanVDRSRate_1704.xls
drwx------  2 adwbat dstage     4096 Jul 14  2016 raym
drwx------  2 adwbat dstage     4096 Jun 15  2016 rayyan
-rwxr--r--  1 adwbat dstage     3020 Apr 26  2016 Reload_Table_Connie2.ksh
-rwx------  1 adwbat dstage  1051924 Mar 31  2016 res.TMP
drwxr-xr-x  3 adwbat dstage     4096 Mar 20  2017 sara
drwx------  8 adwbat dstage     4096 Apr 30 14:38 spt_stephenlee
drwxr-xr-x  2 adwbat dstage     4096 Dec 28  2017 stone
drwxr-xr-x  4 adwbat dstage     4096 May 19  2017 test
-rwxr-xr-x  1 adwbat dstage    13895 May 19  2017 test.pl
-rwx------  1 adwbat dstage  1051924 Apr  5  2016 test.TMP
-rwx------  1 adwbat dstage      625 Jan  5  2016 udsdwuat_adwbat.txt
-rwx------  1 adwbat dstage      459 Jan  5  2016 udsdwuat.txt
drwx------  5 adwbat dstage    20480 Mar  2  2018 vincent
drwx------  3 adwbat dstage    12288 Sep  6  2017 woody
/home/adwbat/tmp> cd ..
/home/adwbat> cat test.file
a1      b       c       d
a2      b       c       d
a3      b       c       d
/home/adwbat> cd ..
/home> cd ..
/> cd /tmp
/tmp> ls -l
total 428008
-rw-------   1 root         root            0 Feb 13 18:41 10477.jsvc_up
-rw-------   1 root         root            0 Jul 29 17:19 7540.jsvc_up
srwx------   1 root         root            0 Jul 29 17:19 __7dea7cf6_@.sock
-rw-r--r--   1 adwbat       dstage         21 Oct 31  2017 8th.log
-rw-rw-r--   1 dsadm        dstage    3824102 Dec  4  2018 a
-rw-rw-r--   1 dsadm        dstage       3785 Apr  4  2018 a.log
-rw-r--r--   1 bpbat        dstage        372 Dec 24  2018 a.pl
-rwxrwxr--   1 dsadm        dstage          0 Feb 13 18:41 apt_resource_track.8001.etl06
-rw-r--r--   1 revrptbat    dstage        254 Sep 27  2017 a.sql
-rw-r--r--   1 bpbat        dstage     160953 Dec 24  2018 a.txt
-rw-r--r--   1 bpbat        dstage       7441 Dec 11  2018 b
-rw-r--r--   1 adwbat       dstage     309248 Dec 24  2018 bm_comm_20161201.xls
-rw-r--r--   1 bpbat        dstage     151040 Aug 29  2018 BM_COMM_20180601.xls
-rw-r--r--   1 adwbat       dstage   18849792 Jun 14  2018 B_RBD_CAP_AMORT_RPT_006B_T_summ1.csv
-rw-r--r--   1 wasadmin     wasadmin       23 Aug  2 17:42 c603c3b1.lck
drwxr-xr-x   2 root         root         4096 Nov 15  2018 cfg2html_temp
-rw-r--r--   1 adwbat       dstage       2166 Mar  7 18:33 Class1.class
-rw-r--r--   1 adwbat       dstage       2405 Mar  7 18:33 Class1.java
-rw-r--r--   1 root         root        13389 Aug 29  2018 config.json
-rw-------   1 adwbat       dstage      38994 Dec 21  2017 crontab.Mz5gju
-rw-------   1 adwbat       dstage      44275 Jan  1  1970 crontab.NB5IBO
-rw-------   1 adwbat       dstage      47094 Feb 28 10:14 crontab.yq8itX
-rw-------   1 adwbat       dstage      48100 Apr  4 14:52 crontab.ZWBUf7
-rw-r--r--   1 adwbat       dstage         25 Jul 26 12:05 datastagetest.file
-rw-r--r--   1 bpbat        dstage     160953 Dec 24  2018 d_bm_cap_amort_rpt_comm_001.dat_bm_comm.txt_20161201
-rw-r--r--   1 modwbat      dstage       1461 Apr 26  2018 dsrt.sql
-rw-rw-r--   1 dsadm        dstage   30548350 May  8  2018 du.tmp
-rw-r--r--   1 revrptbat    dstage      58227 Feb 27 18:42 HS_Bundle_FV_201805.csv
drwxr-xr-x   2 adwbat       dstage       4096 Aug  2 11:53 hsperfdata_adwbat
drwxr-xr-x   2 modwbat      dstage       4096 Aug  2 04:30 hsperfdata_modwbat
drwxr-xr-x   2 root         root         4096 Jul 30 14:47 hsperfdata_root
-rw-r--r--   1 modwbat      dstage        201 Dec 18  2018 idd
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_1115c1d538b6.fs
-rwxrwxr-x   1 adwbat       dstage        131 Dec 22  2018 import_tmp_11854e346a805.fs
-rwxrwxr-x   1 modwbat      dstage        442 Nov 11  2018 import_tmp_11898e89b8e70.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 24  2018 import_tmp_120039652d26.fs
-rwxrwxr-x   1 adwbat       dstage        137 Jul 21  2018 import_tmp_123986051873a.fs
-rwxrwxr-x   1 adwbat       dstage        119 Oct 18  2017 import_tmp_1284534b3f458.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_13188640be700.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_132881ffe154d.fs
-rwxrwxr-x   1 dsadm        dstage        114 Aug 10  2018 import_tmp_133309a0f23fc.fs
-rwxrwxr-x   1 adwbat       dstage        119 Oct 18  2017 import_tmp_1362266da8371.fs
-rwxrwxr-x   1 modwbat      dstage        234 Nov 21  2018 import_tmp_14025a3ac1c1f.fs
-rwxrwxr-x   1 adwbat       dstage        121 Aug  2 16:09 import_tmp_146995db111da.fs
-rwxrwxr-x   1 adwbat       dstage       1908 Apr 27  2018 import_tmp_1510145d86af3.fs
-rwxrwxr-x   1 adwbat       dstage        136 Feb 18 15:06 import_tmp_151697d2c629f.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 24  2018 import_tmp_15860252b7de0.fs
-rwxrwxr-x   1 modwbat      dstage        234 Oct 15  2018 import_tmp_16145e0ae189d.fs
-rwxrwxr-x   1 adwbat       dstage        119 Oct 18  2017 import_tmp_17364968271c9.fs
-rwxrwxr-x   1 modwbat      dstage         75 Aug 28  2018 import_tmp_174058b95bef6.fs
-rwxrwxr-x   1 adwbat       dstage        124 May  8  2018 import_tmp_18146918bd980.fs
-rwxrwxr-x   1 adwbat       dstage        178 Oct 21  2017 import_tmp_18212ea5a9ff1.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_182493d095482.fs
-rwxrwxr-x   1 adwbat       dstage        131 Dec 21  2018 import_tmp_18769e6c4cb07.fs
-rwxrwxr-x   1 adwbat       dstage        119 Oct 18  2017 import_tmp_188672e29bb62.fs
-rwxrwxr-x   1 adwbat       dstage        119 Oct 18  2017 import_tmp_19737641d2c6e.fs
-rwxrwxr-x   1 dsadm        dstage        114 Dec  6  2018 import_tmp_1987557c0270b.fs
-rwxrwxr-x   1 adwbat       dstage        131 Dec 23  2018 import_tmp_2087303cf0a3c.fs
-rwxrwxr-x   1 dsadm        dstage        114 Aug 10  2018 import_tmp_22211be9b3870.fs
-rwxrwxr-x   1 adwbat       dstage        111 Jul 29 12:01 import_tmp_222617fe87ce3.fs
-rwxrwxr-x   1 adwbat       dstage        109 Sep 15  2017 import_tmp_22440b03d784e.fs
-rwxrwxr-x   1 adwbat       dstage        122 Feb 14 04:44 import_tmp_22681afce0cf.fs
-rwxrwxr-x   1 adwbat       dstage        135 Oct 18  2017 import_tmp_23963a00401c7.fs
-rwxrwxr-x   1 adwbat       dstage        109 Sep 15  2017 import_tmp_25838541d3c6e.fs
-rwxrwxr-x   1 dsadm        dstage        114 Aug 10  2018 import_tmp_25892df7b3f90.fs
-rwxrwxr-x   1 adwbat       dstage        131 Dec 22  2018 import_tmp_262642451c33a.fs
-rwxrwxr-x   1 adwbat       dstage        127 Mar 21  2018 import_tmp_2702250c26789.fs
-rwxrwxr-x   1 adwbat       dstage        131 Dec 21  2018 import_tmp_272944a746b57.fs
-rwxrwxr-x   1 modwbat      dstage         75 Aug 28  2018 import_tmp_27337051d4b6e.fs
-rwxrwxr-x   1 dsadm        dstage        114 Dec  4  2018 import_tmp_27876a9452546.fs
-rwxrwxr-x   1 adwbat       dstage        111 Oct 19  2017 import_tmp_289664062afe9.fs
-rwxrwxr-x   1 adwbat       dstage        111 Oct 20  2017 import_tmp_292061871671a.fs
-rwxrwxr-x   1 adwbat       dstage        124 May  8  2018 import_tmp_29326091817b3.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 24  2018 import_tmp_29425b3459b46.fs
-rwxrwxr-x   1 adwbat       dstage        127 Jan 30  2018 import_tmp_306647713f9f8.fs
-rwxrwxr-x   1 adwbat       dstage        131 Dec 23  2018 import_tmp_32963cf86ebc5.fs
-rwxrwxr-x   1 modwbat      dstage        234 Nov 10  2018 import_tmp_33191c67f8b8c.fs
-rwxrwxr-x   1 modwbat      dstage         75 Aug 28  2018 import_tmp_349997b63f1a8.fs
-rwxrwxr-x   1 dsadm        dstage        114 Aug 10  2018 import_tmp_358534a649f67.fs
-rwxrwxr-x   1 adwbat       dstage       3675 Sep 29  2017 import_tmp_36180e4a8a823.fs
-rwxrwxr-x   1 adwbat       dstage       1908 Apr 27  2018 import_tmp_364921a2f3bdc.fs
-rwxrwxr-x   1 adwbat       dstage        109 Sep 15  2017 import_tmp_391689407c404.fs
-rwxrwxr-x   1 adwbat       dstage        127 Jan 31  2018 import_tmp_39876eb831988.fs
-rwxrwxr-x   1 adwbat       dstage        134 Mar 12  2018 import_tmp_40280de2791e4.fs
-rwxrwxr-x   1 adwbat       dstage        111 Oct 19  2017 import_tmp_41662d30faafc.fs
-rwxrwxr-x   1 adwbat       dstage        132 Dec 31  2018 import_tmp_42251edf32b18.fs
-rwxrwxr-x   1 dsadm        dstage        114 Aug 10  2018 import_tmp_422820c463f05.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_44694b5426309.fs
-rwxrwxr-x   1 dsadm        dstage        114 Aug 10  2018 import_tmp_4695496bc350f.fs
-rwxrwxr-x   1 adwbat       dstage        111 Oct 20  2017 import_tmp_47022279c312.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 24  2018 import_tmp_47798687b7690.fs
-rwxrwxr-x   1 modwbat      dstage         75 Aug 28  2018 import_tmp_481039d1cdba.fs
-rwxrwxr-x   1 adwbat       dstage        127 Mar 21  2018 import_tmp_497500184c047.fs
-rwxrwxr-x   1 adwbat       dstage        124 Sep  6  2018 import_tmp_53193b58cf23f.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_549327f4748c4.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_551546333a5d8.fs
-rwxrwxr-x   1 adwbat       dstage        132 Dec 31  2018 import_tmp_57995cc882843.fs
-rwxrwxr-x   1 adwbat       dstage        162 Mar 29  2018 import_tmp_584013cef291c.fs
-rwxrwxr-x   1 adwbat       dstage        127 Mar 21  2018 import_tmp_60167fa334ed8.fs
-rwxrwxr-x   1 adwbat       dstage        162 Mar 29  2018 import_tmp_609662e2741e4.fs
-rwxrwxr-x   1 adwbat       dstage        132 Dec 31  2018 import_tmp_615989acbc040.fs
-rwxrwxr-x   1 dsadm        dstage        152 Feb 18 17:49 import_tmp_6190344b55dd6.fs
-rwxrwxr-x   1 adwbat       dstage        124 Sep  6  2018 import_tmp_6497607d965b2.fs
-rwxrwxr-x   1 adwbat       dstage        127 Jan 31  2018 import_tmp_6541659b78254.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 25  2018 import_tmp_775741d1c6e.fs
-rwxrwxr-x   1 adwbat       dstage        127 Jan 30  2018 import_tmp_80685a5ca96f.fs
-rwxrwxr-x   1 adwbat       dstage        127 Mar 21  2018 import_tmp_98050350e77b.fs
-rwxrwxr-x   1 adwbat       dstage        119 Apr 27  2018 import_tmp_98274e493342.fs
-rw-r-----   1 modwbat      dstage   60644752 Oct 16  2018 infile.101520
drwxr-xr-x   3 wasadmin     wasadmin     4096 Nov  8  2018 informationServer
-rw-rw-r--   1 root         root            0 Feb 13 18:41 itm5952540347887517378.itm
drwxrwxrwx   2 root         root         4096 Dec  1  2014 javasharedresources
drwxr-xr-x   2 root         root         4096 Nov 17  2006 jce
-rw-------   1 silvesterman users         554 Jun  9 07:04 krb5cc_459800023_sdZ81w
-rw-------   1 jackiefong   users         548 May  6 19:45 krb5cc_459800025_AyaR8c
-rw-------   1 louislaw     users         542 Jul 30 18:07 krb5cc_459800026_K31NXp
-rw-------   1 seanwong     users         542 Apr  8 09:26 krb5cc_459800030_oFfYpL
-rw-------   1 ryanku       users         535 Jun 10 02:40 krb5cc_459800034_elsQgK
-rw-------   1 wtli         users         529 Jun  8 20:59 krb5cc_459800035_iCDujC
-rw-------   1 lewischan    users         545 Jul 29 15:56 krb5cc_459800037_kt6F0N
-rw-------   1 ansonho      users         539 Apr 10 10:48 krb5cc_459800039_YXD0A9
-rw-------   1 hkfan        users         532 Aug  1 14:32 krb5cc_459800054_76tzDg
-rw-------   1 irenekan     users         542 Aug  2 16:54 krb5cc_459800055_fXC6eZ
-rw-------   1    459800062 users         548 Mar 12  2018 krb5cc_459800062_N7FwtW
-rw-------   1 kevinou      users         539 May 30  2018 krb5cc_459800068_14gd9z
-rw-------   1 kevinou      users         539 Nov 23  2017 krb5cc_459800068_8Y2G4x
-rw-------   1 kevinou      users         539 Sep  5  2018 krb5cc_459800068_O6zg7G
-rw-------   1 kevinou      users         539 Aug  2 10:04 krb5cc_459800068_vkaNB2
-rw-------   1 nelsonhung   users         548 Jun 28 09:32 krb5cc_459800074_rrHr2b
-rw-------   1 paulcwwong   users         548 Aug  2 09:35 krb5cc_459800077_BHylbA
-rw-------   1 raywong      users         539 Jul  2 11:39 krb5cc_459800079_wKBZAd
-rw-------   1 rickhuang    users         545 Jul 29 17:23 krb5cc_459800080_GqrNT3
-rw-------   1 stephenlee   users         548 Aug  2 09:59 krb5cc_459800082_oKzUKk
-rw-------   1 stoneshek    users         545 Aug  2 09:28 krb5cc_459800083_7DRhXI
-rw-------   1 vanessatan   users         548 Jul 15 16:38 krb5cc_459800085_xhp9or
-rw-------   1 nestorchen   users         548 Apr 23  2018 krb5cc_459800095_Ico1u9
-rw-------   1 rayyan       users         535 Apr  3  2018 krb5cc_459800119_1ZDUIC
-rw-------   1 billliang    users         545 May 10  2018 krb5cc_459800120_BFHtIo
-rw-------   1    459800121 users         539 Apr 25 10:01 krb5cc_459800121_C5kE70
-rw-------   1 carmenchik   users         548 Aug  2 09:20 krb5cc_459800129_Oac0ZY
-rw-------   1 joechan      users         539 Aug  2 09:46 krb5cc_459800176_vuEEuf
-rw-------   1 stephenho    users         545 May 23 11:04 krb5cc_459800186_jG8M1w
-rw-------   1 teddywong    users         545 Jul 30 09:31 krb5cc_459800204_d7WZO9
-rw-------   1 thchan       users         535 Jul 23 09:24 krb5cc_459800209_zGTFmN
-rw-------   1 davidtsai    users         545 Jul 10 16:00 krb5cc_459800242_SFEve7
-rw-------   1 raymondho    users         545 Jun 11 14:20 krb5cc_459800299_eEyBPr
-rw-------   1 barrylu      users         539 Aug  2 15:54 krb5cc_459800312_RXw6g2
-rw-------   1 stevenng     users         542 Jul 29 09:24 krb5cc_459800346_gAY1qV
-rw-------   1 eloisewu     users         542 Aug  1 09:30 krb5cc_459800369_R1vOSj
drwx------.  2 root         root        16384 Jun 19  2014 lost+found
-rw-r--r--   1 root         root        61440 Feb 14 09:31 lo.tar
-rw-rw-rw-   1 dsadm        dstage   50637780 Feb  9 18:53 machineLog.8001.etl06.smartone.com.20190208185307
-rw-rw-rw-   1 dsadm        dstage   49529832 Feb 10 18:53 machineLog.8001.etl06.smartone.com.20190209185310
-rw-rw-rw-   1 dsadm        dstage   49552341 Feb 11 18:53 machineLog.8001.etl06.smartone.com.20190210185314
-rw-rw-rw-   1 dsadm        dstage   49584321 Feb 12 18:53 machineLog.8001.etl06.smartone.com.20190211185316
-rw-rw-rw-   1 dsadm        dstage   47608767 Feb 13 17:54 machineLog.8001.etl06.smartone.com.20190212185318
-rw-rw-rw-   1 dsadm        dstage          0 Feb 13 18:42 machineLog.8001.etl06.smartone.com.20190213184136
-rw-r--r--   1 adwbat       dstage       1288 Mar  7 18:25 MD5Encrypt.class
-rw-r--r--   1 adwbat       dstage       1247 Mar  7 18:25 MD5Encrypt.java
drwxrwxrwx   5 root         root         4096 Oct  8  2015 module
-rw-------   1 adwbat       dstage          0 Apr 24 17:43 mutt-etl06-505-59201-0
-rw-------   1 adwbat       dstage          0 Apr 24 17:44 mutt-etl06-505-59746-0
-rw-------   1 revrptbat    dstage          1 Aug  6  2018 mutt-etl06-530-18155-0
-rw-------   1 revrptbat    dstage          0 Nov 22  2018 mutt-etl06-530-429-0
-rw-------   1 modwbat      dstage          0 Sep 10  2018 mutt-etl06-540-3141-0
-rw-------   1 modwbat      dstage          0 May 30 14:52 mutt-etl06-540-33113-0
-rw-------   1 modwbat      dstage          0 Mar 20  2018 mutt-etl06-540-40111-0
-rw-r--r--   1 kevinou      users        1761 Nov 27  2017 niq.sql
-rw-rw-r--   1 dsadm        dstage         49 Jan 30  2018 output.txt
-rw-r--r--   1 root         root        51625 Jul  9 12:01 ps_ax.output
-rw-r--r--   1 revrptbat    dstage     741545 Nov 16  2018 quotation_rebate_20181108.txt.zip
-rw-rw-r--   1 dsadm        dstage          8 Jul 31  2018 rbd_staff_dup.err
-rw-rw-r--   1 dsadm        dstage        228 Jul 31  2018 rbd_staff_term.err
-rw-rw-rw-   1 dsadm        users           0 Feb 13 18:41 resource_tracker.8001.log
-rw-r--r--   1 root         root        24850 Jul  9 12:01 results
-rw-r--r--   1 nobody       nobody       6007 Aug 11  2015 silent_config_00_apitm04.txt
-rw-r--r--   1 nobody       nobody       6007 Aug 11  2015 silent_config_01_apitm04.txt
-rwxr-xr-x   1 root         root       504232 Nov 29  2017 sqlite-3.6.18-libsqlitejdbc.so
-rw-r--r--   1 adwbat       dstage      54750 Oct  2  2018 t
drwxr-xr-x   2 adwbat       dstage       4096 May  2 19:46 temp
-rw-r--r--   1 adwbat       dstage         26 Jul 26 11:40 test.file
-rw-r--r--   1 bpbat        dstage       7999 Oct 22  2018 tmp
-rw-rw-r--   1 dsadm        dstage          0 Dec  4  2017 unload_fl_ofta_oper_ref.dat
-rw-rw-r--   1 dsadm        dstage          0 Dec  4  2017 unload_fl_oper_ref.dat
-rw-r--r--   1 adwbat       dstage          0 Aug  2 09:01 unload_modw_billtrxactcust.20190802.complete
-rw-rw-r--   1 adwbat       dstage    3227153 Aug  2 09:01 unload_modw_billtrxactcust.dat
-rw-r--r--   1 adwbat       dstage          0 Aug  2 09:00 unload_modw_billtrxasubr.20190802.complete
-rw-rw-r--   1 adwbat       dstage    3553267 Aug  2 09:00 unload_modw_billtrxasubr.dat
-rw-r--r--   1 adwbat       dstage          0 Jul  4 08:07 unload_modw_hkbillcallrec.20190704.complete
-rw-rw-r--   1 adwbat       dstage   46006349 Jul  4 08:07 unload_modw_hkbillcallrec.dat
-rw-r--r--   1 adwbat       dstage          0 Jul  4 08:25 unload_modw_hktapin.20190704.complete
-rw-rw-r--   1 adwbat       dstage   14838646 Jul  4 08:25 unload_modw_hktapin.dat
-rw-r--r--   1 adwbat       dstage          0 Jul  4 08:02 unload_modw_hktapout.20190704.complete
-rw-rw-r--   1 adwbat       dstage    6265626 Jul  4 08:02 unload_modw_hktapout.dat
-rw-r--r--   1 adwbat       dstage          0 Aug  2 08:34 unload_modw_subr_event.20190802.complete
-rw-rw-r--   1 adwbat       dstage         53 Aug  2 08:34 unload_modw_subr_event.dat
drwx------   2 adwbat       dstage       4096 Aug  2 16:37 vtjkMVP
drwxr-xr-x  10 adwbat       dstage       4096 Jan 26  2018 wtrdblog
-rw-------   1 root         root       414317 Aug 29  2018 yum_save_tx-2018-08-29-18-07Agw2_s.yumtx
drwxr-xr-x   2 root         root         4096 Jul 29 17:19 zenworks-authss
drwxr-xr-x   2 root         root         4096 Jul 29 17:19 zenworks-joinproxyss
/tmp> cd /home/adwbat/
/home/adwbat> cd o_to_s
-bash: cd: o_to_s: No such file or directory
/home/adwbat> cd s_to_o
/home/adwbat/s_to_o> pwd
/home/adwbat/s_to_o
/home/adwbat/s_to_o> ^C
/home/adwbat/s_to_o> ls -l
total 4
-rw-r--r-- 1 adwbat dstage 16 Aug  2 17:36 test.txt
