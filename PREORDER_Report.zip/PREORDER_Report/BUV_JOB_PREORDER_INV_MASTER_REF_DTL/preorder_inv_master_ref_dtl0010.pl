######################################################
#   $Header: /CVSROOT/SmarTone-Vodafone/Code/ETL/APP/Template/b_JobName0010.pl,v 1.1 2005/12/14 01:04:45 MichaelNg Exp $
#   Purpose:
#
#
######################################################

#*#
#my $ETLVAR = $ENV{"AUTO_ETLVAR"};require $ETLVAR;
my $ETLVAR =  "/opt/etl/prd/etl/APP/BUV/PREORDER_INV_MASTER_REF_DTL/bin/master_dev.pl";
require $ETLVAR;
my $MASTER_TABLE = ""; #Please input the final target ADW table name here

sub runSQLPLUS{
  #*#my $SQLCMD_FILE="${etlvar::AUTO_GEN_TEMP_PATH}${etlvar::ETLJOBNAME}_sqlcmd.sql";
  my $SQLCMD_FILE="/opt/etl/prd/etl/APP/BUV/PREORDER_INV_MASTER_REF_DTL/bin/preorder_inv_master_ref_dtl0010_sqlcmd.sql";#*#
  open SQLCMD, ">" . $SQLCMD_FILE || die "Cannot open file" ;
  print SQLCMD<<ENDOFINPUT;
#*#
whenever sqlerror exit 2;
set serveroutput on;
set sqlblanklines on;
set autocommit 1;
set timing on;
set echo on;
set sqlnumber off;
set define off;
#ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';
#*#

#*#${etlvar::LOGON_TD}
#*#${etlvar::SET_MAXERR}
#*#${etlvar::SET_ERRLVL_1}
#*#${etlvar::SET_ERRLVL_2}

#*#--Please type your SQL statement here
#*#------------------------------------------------------------------------------------------------

#*#
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.PREORDER_INV_MASTER_REF_DTL');



#*#insert /*+ APPEND parallel(64) */ into ${etlvar::TMPDB}.B_RELAY42_LIST_001_TMP
 insert /*+ APPEND parallel(64) */ into ${etlvar::TMPDB}.PREORDER_INV_MASTER_REF_DTL
(
 INV_DATE
,PROD_GROUP
,PROD_CD
,PROD_LONG_DESC
,PROD_SHORT_DESC
,SERIES
,PRODUCT_NATURE
,COLOR
,PROD_ORDER1
,PROD_ORDER2
,D_CUST_NATURE
,D_CUST_NATURE_ORDER
,D_MKT_CD
,D_MKT_CD_ORDER
,D_PRICE_LIST
,D_PRICE_LIST_ORDER
,D_POS_SHOP_CD
,D_POS_SHOP_CD_ORDER
,D_PREPAID_IND
,D_PREPAID_IND_ORDER
,QTY
)
select 
 op_date
,a.PROD_CD
,a.PROD_GROUP
,a.PROD_LONG_DESC
,a.PROD_SHORT_DESC
,a.SERIES
,a.PRODUCT_NATURE
,a.COLOR
,a.DISPLAYORDER_1
,a.DISPLAYORDER_2
,b.VAL AS D_CUST_NATURE
,b.DisplayOrder AS D_CUST_NATURE_ORDER
,c.VAL AS D_MKT_CD
,c.DisplayOrder AS D_MKT_CD_ORDER
,d.VAL AS D_PRICE_LIST
,d.DisplayOrder AS D_PRICE_LIST_ORDER
,e.VAL AS D_POS_SHOP_CD
,e.DisplayOrder AS D_POS_SHOP_CD_ORDER
,f.VAL AS D_PREPAID_IND
,f.DisplayOrder AS D_PREPAID_IND_ORDER
,0 AS QTY
from ${etlvar::TMPDB}.PREORDER_PROD_REF a
left outer join 
(select KEY_GROUP,VAL,DisplayOrder 
        FROM ${etlvar::TMPDB}.PREORDER_INV_MASTER_REF 
        where COL = 'D_CUST_NATURE') b
on a.PROD_GROUP = b.KEY_GROUP
left outer join 
(select KEY_GROUP,VAL,DisplayOrder 
        from ${etlvar::TMPDB}.PREORDER_INV_MASTER_REF 
        where COL = 'D_MKT_CD') c
on a.PROD_GROUP = c.KEY_GROUP
left outer join 
(select KEY_GROUP,VAL,DisplayOrder 
        from ${etlvar::TMPDB}.PREORDER_INV_MASTER_REF 
        where COL = 'D_PRICE_LIST') d
on a.PROD_GROUP = d.KEY_GROUP
left outer join 
(select KEY_GROUP,VAL,DisplayOrder 
        from MIG_ADW.PREORDER_INV_MASTER_REF 
        where COL = 'D_POS_SHOP_CD') e
on a.PROD_GROUP = e.KEY_GROUP
left outer join 
(select KEY_GROUP,VAL,DisplayOrder 
        from MIG_ADW.PREORDER_INV_MASTER_REF 
        where COL = 'D_PREPAID_IND') f
on a.PROD_GROUP = f.KEY_GROUP,
(select  date '2000-01-01' + rownum -1 op_date from dual connect by rownum<36500 ) bb  
where bb.op_date between a.eff_start_date and least(TRUNC (SYSDATE),a.eff_end_date);
COMMIT;
exit;

ENDOFINPUT
  close(SQLCMD);
  print("sqlplus /\@${etlvar::TDDSN} \@$SQLCMD_FILE");
  my $ret = system("sqlplus /\@${etlvar::TDDSN} \@$SQLCMD_FILE");
  if ($ret != 0)
  {
    return (1);
  }
  return 0;

}

#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_cust_info0010.pl adw_b_cust_info_20051010.dir\n");
    exit(1);
}




#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);
my $ret = runSQLPLUS();
my $post = etlvar::postProcess();

exit($ret);


