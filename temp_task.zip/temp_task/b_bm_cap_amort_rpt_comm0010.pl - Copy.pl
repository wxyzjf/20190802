######################################################
#   $Header: /CVSROOT/SmarTone-Vodafone/Code/ETL/Template/b_JobName0010.pl,v 1.2 2005/11/16 08:35:06 MichaelNg Exp $
#   Purpose:
#
#
######################################################


my $ETLVAR = $ENV{"AUTO_ETLVAR"};
#my $ETLVAR = "/opt/etl/prd/etl/APP/ADW/B_BM_CAP_AMORT_RPT_COMM/bin/master_dev.pl";
require $ETLVAR;

my $MASTER_TABLE = ""; #Please input the final target ADW table name here

sub runSQLPLUS{
    my $rc = open(SQLPLUS, "| sqlplus /\@${etlvar::TDDSN}");
    unless ($rc){
        print "Cound not invoke SQLPLUS command\n";
        return -1;
    }

print SQLPLUS<<ENDOFINPUT;
        ${etlvar::LOGON_TD}
        ${etlvar::SET_MAXERR}
        ${etlvar::SET_ERRLVL_1}
        ${etlvar::SET_ERRLVL_2}


--Please type your SQL statement here
alter session force parallel query parallel 30;
alter session force parallel dml parallel 30;

execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_001_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_001A_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_002A_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_003A_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_003B_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_004A_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_004B_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_004C_T');
execute ${etlvar::UTLDB}.ETL_UTILITY.TRUNCATE_TBL(p_table_schema=>'${etlvar::TMPDB}',p_table_name=>'B_BM_CAP_AMORT_RPT_005A_T');
DELETE FROM ${etlvar::ADWDB}.BM_CAP_AMORT_RPT_H WHERE rpt_mth = ADD_MONTHS( to_date('$etlvar::TXMONTH','YYYYMM'), - 0);



set define on;
define rpt_mth=to_date('$etlvar::F_D_MONTH[0]','YYYY-MM-DD');
define rpt_s_date=to_date('$etlvar::F_D_MONTH[0]','YYYY-MM-DD');
define rpt_e_date=add_months(to_date('$etlvar::F_D_MONTH[0]','YYYY-MM-DD'),1)-1;


prompt '[ Prepare the seq 0 case ]';

insert into  ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_001_T
(
        UNIQ_KEY
        ,ACT_MTH
        ,CUST_NUM
        ,SUBR_NUM
        ,SALESMAN
        ,CUST_TYPE
        ,CUST_NAME
        ,SUBR_STAT_CD
        ,SUBR_SW_ON_DATE
        ,AMORT_PERIOD_MTH
        ,AMORT_EXPIRY_DATE
        ,SERV_REV_COMM
        ,CREATE_TS
        ,REFRESH_TS
)
select to_char(&rpt_mth,'yyyymmdd')||'_'||row_number() over (order by cust_num,subr_num) unqi_key
    ,act_mth
    ,cust_num
    ,subr_num
    ,salesman
    ,cust_type
    ,cust_name
    ,subr_stat_cd
    ,subr_sw_on_date
    ,amort_period_mth
    ,TO_DATE('${etlvar::MAXDATE}','yyyy-mm-dd') as amort_expiry_date --subr_sw_on_date + (AMORT_PERIOD_MTH/ 12 * 365 + 1) as amort_expiry_date
    ,serv_rev_comm
    ,sysdate
    ,sysdate
from ${etlvar::TMPDB}.D_BM_CAP_AMORT_RPT_COMM
where act_mth = add_months(&rpt_mth,-4);
commit;

--
--
--
--prompt '[ Start Preparing the profile info and Seq > 0 case  ]' ;


insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_002A_T
(
        Rpt_Mth
        ,Uniq_Key
        ,cust_num
        ,subr_num
        ,Trx_date
        ,Action
        ,Orig_Subr_Num
        ,Orig_Cust_Num
)
select
        &rpt_mth
        ,'CHG_NO_'||row_number() over (order by image_date,cust_num,subr_num,orig_subr_Num)
        ,trx.cust_num
        ,trx.subr_num
        ,trx.Image_Date
        ,trx.Action
        ,trx.Orig_Subr_Num
        ,trx.cust_num
from ${etlvar::ADWDB}.NEW_ACTV_LIST trx
where trx.action in ('M')
---- swap to ppd and back to postpd at 2017-05-15---
 and subr_num <> '97271535'
 and image_date between  add_months(&rpt_s_date,-4) and &rpt_e_date;
commit;

prompt '[ Prepare change cust num case ]';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_002A_T
(
        Rpt_Mth
        ,Uniq_Key
        ,cust_num
        ,subr_num
        ,Trx_date
        ,Action
        ,Orig_Subr_Num
        ,Orig_Cust_Num
)
select
        &rpt_mth
        ,'CHG_CUST_'||row_number() over (order by chg_cust_ok.subr_sw_on_date
                                                ,chg_cust_ok.cust_num
                                                ,chg_cust_ok.subr_num
                                                ,chg_cust_ok.acct_num
                                                ,chg_cust_tx.subr_Num)
        ,chg_cust_ok.cust_num
        ,chg_cust_ok.subr_num
        ,chg_cust_ok.subr_sw_on_date as trx_date
        ,'CHG_CUST' as ACTION
        ,chg_cust_tx.subr_num
        ,chg_cust_tx.cust_num
  from  ${etlvar::ADWDB}.subr_info_hist chg_cust_tx
       ,${etlvar::ADWDB}.subr_info_hist chg_cust_ok
where    chg_cust_tx.subr_sw_off_date = chg_cust_ok.subr_sw_on_date
        and chg_cust_tx.disc_reason_cd in ('77','HO','SAHO')
        and chg_cust_tx.subr_stat_cd in ('TX')
        and chg_cust_tx.subr_sw_off_date = chg_cust_ok.subr_sw_on_date
        and chg_cust_ok.subr_stat_cd = 'OK'
        and chg_cust_tx.subr_stat_cd <> 'OK'
        and chg_cust_ok.subr_sw_on_date between add_months(&rpt_s_date,-4) and &rpt_e_date
        and chg_cust_tx.end_date = to_date('${etlvar::MAXDATE}','yyyy-mm-dd')
        -----and chg_cust_ok.end_date = ${etlvar::MAXDATE}
        and chg_cust_ok.start_date between  add_months(&rpt_s_date,-4) and &rpt_e_date
        and chg_cust_ok.start_date = chg_cust_ok.subr_sw_on_date
        and chg_cust_tx.subr_num = chg_cust_ok.subr_num
        and chg_cust_tx.cust_num <> chg_cust_ok.cust_num;
commit;

prompt 'Prepare change new case ';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_002A_T
(
        Rpt_Mth
        ,Uniq_Key
        ,cust_num
        ,subr_num
        ,Trx_date
        ,Action
        ,Orig_Subr_Num
        ,Orig_Cust_Num
)
select
        &rpt_mth
        ,t.uniq_key
        ,t.cust_num
        ,t.subr_num
        ,t.subr_sw_on_date as trx_date
        ,'NEW_CASE' as ACTION
        ,t.subr_num as Orig_Subr_Num
        ,t.cust_num as Orig_Cust_Num
from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_001_T t;

commit;
prompt '[ Calculate the seq 0 profile change case.and find out the month end profile number]';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_003A_T
(
        RPT_MTH
        ,UNIQ_KEY
        ,FST_CUST_NUM
        ,FST_SUBR_NUM
        ,SUBR_SW_ON_DATE
        ,CUST_NUM
        ,SUBR_NUM
        ,MIN_TRX_DATE
        ,MAX_TRX_DATE
        ,CREATE_TS
        ,REFRESH_TS
)select
        &rpt_mth
        ,fst_uniq_key
        ,fst_cust_num
        ,fst_subr_num
        ,fst_trx_date as subr_sw_on_date
        ,max(cust_num) keep (dense_rank first order by lv desc) final_cust_num
        ,max(subr_num) keep (dense_rank first order by lv desc) final_subr_num
        ,min(trx_date) as min_trx_date
        ,max(trx_date) as max_trx_date
        ,sysdate
        ,sysdate
 from (
    Select
         connect_by_root(t.orig_cust_num) as fst_cust_num
        ,connect_by_root(t.orig_subr_num) as fst_subr_num
        ,connect_by_root(t.trx_date) as fst_trx_date
        ,connect_by_root(t.uniq_key) as fst_uniq_key
        ,level lv
        ,t.cust_num
        ,t.subr_num
        ,t.trx_date
    from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_002A_T t
    start with t.action  in ('NEW_CASE')
    connect by prior t.cust_num = t.orig_cust_num
        and prior t.subr_num = t.orig_subr_num
        and prior t.trx_date < t.trx_date
        and t.action not in ('NEW_CASE','LAST_MTH_CASE')
)  where trx_date <= &rpt_e_date
group by fst_cust_num
        ,fst_subr_num
        ,fst_trx_date
        ,fst_uniq_key;

----Calculate the seq 1 case with month end date image---
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_003B_T
(
        rpt_mth
        ,uniq_key
        ,orig_cust_num
        ,orig_subr_num
        ,act_month
        ,subr_sw_on_date
        ,cust_num
        ,subr_num
        ,seq
        ,subr_stat_cd
        ,subr_sw_off_date
        ,amort_period_mth
        ,amort_expiry_date
        ,serv_rev_comm
        ,trx_date
        ,ca_serv_rev_comm_amt
        ,ca_amort_amt
        ,ca_unamort_cf_amt
        ,cab_unamort_bf_amt
        ,cab_diff_unam_am_amt
        ,cab_unamort_cf_amt
        ,ttl_unamort_bf_amt
        ,ttl_diff_comm_cm_amt
        ,ttl_amort_amt
        ,ttl_unamort_cf_amt
        ,salesman
        ,cust_name
        ,create_ts
        ,refresh_ts
)
select
         &rpt_mth
        ,t.uniq_key
        ,t.cust_num as orig_cust_num
        ,t.subr_num as orig_subr_num
        ,trunc(t.subr_sw_on_date,'MM') as act_mth
        ,t.subr_sw_on_date
        ,r.cust_num
        ,r.subr_num
        ,1 as seq
        ,nvl(p.subr_stat_cd,' ') as subr_stat_cd
        ,nvl(p.subr_sw_off_date,to_date('${etlvar::MAXDATE}','yyyy-mm-dd')) as subr_sw_off_date
        ,t.amort_period_mth
        ,t.subr_sw_on_date + (t.amort_period_mth / 12 * 365 + 1) as amort_expiry_date
        ,t.serv_rev_comm
        ,&rpt_e_date as trx_date
        ,t.serv_rev_comm as ca_serv_rev_comm_amt
        ,round(t.serv_rev_comm/(t.amort_period_mth - 4 ),2) as ca_amort_amt
        ,t.serv_rev_comm  - round(t.serv_rev_comm/(t.amort_period_mth - 4 ),2)  as ca_unamort_cf_amt
        ,0 as cab_unamort_bf_amt
        ,0 as cab_diff_unam_am_amt
        ,0 as cab_unamort_cf_amt
        ,0 as ttl_unamort_bf_amt
        ,0 as ttl_diff_comm_cm_amt
        ,0 as ttl_amort_amt
        ,0 as ttl_unamort_cf_amt
        ,t.salesman
        ,t.cust_name
        ,sysdate as create_ts
        ,sysdate as refresh_ts
from
     ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_001_T t
left outer join ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_003A_T r
        on t.uniq_key = r.uniq_key
left outer join ${etlvar::ADWDB}.subr_info_hist p
        on r.subr_num = p.subr_num
       and r.cust_num = p.cust_num
       and &rpt_e_date between p.start_date and p.end_date;
commit;

prompt '[ Handle the seq 1 case end with current month(subr_status in TX ,SU) and serv_rev_comm < 1]';


prompt '[ Check those case mth end status not in OK SU ]';
--update MIG_ADW.B_BM_CAP_AMORT_RPT_003B_T t
--      set calc_remark = case
--                              --when  subr_stat_cd not in ('OK','SU')
--                              --then  calc_remark||';Error with incorrect subr_stat_cd'
--                        when  serv_rev_comm <=0
--                      then calc_remark||';Error with serv_rev_comm <=0'
--                      end
--         ,calc_status = 'ERROR'
--where serv_rev_comm <=0;
--commit;
-----Amrotise in first month ----
update  ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_003B_T
        set ca_amort_amt = ca_serv_rev_comm_amt
            ,ca_unamort_cf_amt = 0
            ,calc_remark =  calc_remark || case when  subr_stat_cd in ('TX','SU')
                                then ';End Case at first month with TX SU'
                                when abs(ca_serv_rev_comm_amt) < 1
                                then  ';End Case at first month with ca_serv_rev_comm_amt <1'
                                when amort_period_mth < 4
                                then ';End by period less than 4'
                                end
            ,calc_status ='END_CASE'
where subr_stat_cd in ('TX','SU')
        or abs(ca_serv_rev_comm_amt) <1
-----UPD20190510--- End case when period <4
        or amort_period_mth<4;
commit;

prompt '[ Calculate the amount info ]';
update ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_003B_T t
        set  cab_unamort_bf_amt = 0
             ,cab_diff_unam_am_amt = 0
             ,cab_unamort_cf_amt = 0
             ,ttl_unamort_bf_amt = 0
             ,ttl_diff_comm_cm_amt = ca_serv_rev_comm_amt
             ,ttl_amort_amt = ca_amort_amt + cab_diff_unam_am_amt
                ----- ttl_unamort_bf_amt + ttl_diff_comm_cm_amt - ttl_amort_amt
             ,ttl_unamort_cf_amt = 0 + ca_serv_rev_comm_amt - (ca_amort_amt + cab_diff_unam_am_amt);
commit;







prompt '[Preparing the history for Last mth caes ]';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004A_T
(
    rpt_mth
    ,uniq_key
    ,orig_cust_num
    ,orig_subr_num
    ,subr_sw_on_date
    ,cust_num
    ,subr_num
    ,seq
    ,subr_stat_cd
    ,amort_period_mth
    ,amort_expiry_date
    ,serv_rev_comm
    ,trx_date
    ,ca_serv_rev_comm_amt
    ,ca_amort_amt
    ,ca_unamort_cf_amt
    ,cab_unamort_bf_amt
    ,cab_diff_unam_am_amt
    ,cab_unamort_cf_amt
    ,ttl_unamort_bf_amt
    ,ttl_diff_comm_cm_amt
    ,ttl_amort_amt
    ,ttl_unamort_cf_amt
    ,salesman
    ,cust_name
    ,act_month
    ,calc_remark
    ,calc_status
    ,create_ts
    ,refresh_ts
)
select
    &rpt_mth
    ,uniq_key
    ,orig_cust_num
    ,orig_subr_num
    ,subr_sw_on_date
    ,cust_num
    ,subr_num
    ,seq
    ,subr_stat_cd
    ,amort_period_mth
    ,amort_expiry_date
    ,serv_rev_comm
    ,trx_date
    ,ca_serv_rev_comm_amt
    ,ca_amort_amt
    ,ca_unamort_cf_amt
    ,cab_unamort_bf_amt
    ,cab_diff_unam_am_amt
    ,cab_unamort_cf_amt
    ,ttl_unamort_bf_amt
    ,ttl_diff_comm_cm_amt
    ,ttl_amort_amt
    ,ttl_unamort_cf_amt
    ,salesman
    ,cust_name
    ,act_month
    ,calc_remark
    ,calc_status
    ,create_ts
    ,refresh_ts
from ${etlvar::ADWDB}.BM_CAP_AMORT_RPT_H t
where t.rpt_mth = add_months(&rpt_mth ,-1)
and t.calc_status not in ('END_CASE','ERROR')
  and (t.uniq_key,t.seq) in (
        select h.uniq_key,max(h.seq)
        from ${etlvar::ADWDB}.BM_CAP_AMORT_RPT_H h
        where h.rpt_mth = add_months(&rpt_mth ,-1)
          and h.calc_status not in ('END_CASE','ERROR')
         group by h.uniq_key
  );

prompt '[Calculate the amount for Last mth caes ]';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_002A_T
(
        Rpt_Mth
        ,Uniq_Key
        ,cust_num
        ,subr_num
        ,Trx_date
        ,Action
        ,Orig_Subr_Num
        ,Orig_Cust_Num
)
select
        &rpt_mth
        ,t.uniq_key
        ,t.cust_num
        ,t.subr_num
        ,t.subr_sw_on_date as trx_date
        ,'LAST_MTH_CASE' as ACTION
        ,t.subr_num as Orig_Subr_Num
        ,t.cust_num as Orig_Cust_Num
from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004A_T t;

--MIG_ADW.B_BM_CAP_AMORT_RPT_H t
--where t.rpt_mth = add_months(&rpt_mth ,-1)
--  and t.calc_status not in ('END_CASE','ERROR')
--  and (t.uniq_key,t.seq) in (
--      select h.uniq_key,max(h.seq)
--      from MIG_ADW.B_BM_CAP_AMORT_RPT_H h
--      where h.rpt_mth = add_months(&rpt_mth ,-1)
--        and h.calc_status not in ('END_CASE','ERROR')
--  );

prompt '[Calculate the change profile case ]';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004B_T
(
        RPT_MTH
        ,UNIQ_KEY
        ,FST_CUST_NUM
        ,FST_SUBR_NUM
        ,SUBR_SW_ON_DATE
        ,CUST_NUM
        ,SUBR_NUM
        ,MIN_TRX_DATE
        ,MAX_TRX_DATE
        ,SEQ
        ,CREATE_TS
        ,REFRESH_TS
)select
        &rpt_mth
        ,fst_uniq_key
        ,fst_cust_num
        ,fst_subr_num
        ,fst_trx_date as subr_sw_on_date
        ,cust_num
        ,subr_num
        ,trx_date as min_trx_date
        ,trx_date as max_trx_date
        ,row_number() over (partition by fst_uniq_key order by trx_date)
        ,sysdate
        ,sysdate
 from (
    Select
         connect_by_root(t.orig_cust_num) as fst_cust_num
        ,connect_by_root(t.orig_subr_num) as fst_subr_num
        ,connect_by_root(t.trx_date) as fst_trx_date
        ,connect_by_root(t.uniq_key) as fst_uniq_key
        ,level lv
        ,t.cust_num
        ,t.subr_num
        ,t.trx_date
        ,t.action
    from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_002A_T t
    start with t.action  in ('LAST_MTH_CASE')
    connect by prior t.cust_num = t.orig_cust_num
        and prior t.subr_num = t.orig_subr_num
        and prior t.trx_date < t.trx_date
        and t.action not in ('NEW_CASE','LAST_MTH_CASE')
)  where trx_date <= &rpt_e_date;
commit;

prompt '[Calculate the change case ]';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T
(
    rpt_mth
    ,uniq_key
    ,orig_cust_num
    ,orig_subr_num
    ,subr_sw_on_date
    ,cust_num
    ,subr_num
    ,seq
    ,subr_stat_cd
    ,subr_sw_off_date
    ,amort_period_mth
    ,amort_expiry_date
    ,serv_rev_comm
    ,trx_date
    ,ca_serv_rev_comm_amt
    ,ca_amort_amt
    ,ca_unamort_cf_amt
    ,cab_unamort_bf_amt
    ,cab_diff_unam_am_amt
    ,cab_unamort_cf_amt
    ,ttl_unamort_bf_amt
    ,ttl_diff_comm_cm_amt
    ,ttl_amort_amt
    ,ttl_unamort_cf_amt
    ,salesman
    ,cust_name
    ,act_month
    ,calc_remark
    ,calc_status
    ,create_ts
    ,refresh_ts
)
select
    &rpt_mth
    ,tb.uniq_key
    ,tb.fst_cust_num as orig_cust_num
    ,tb.fst_subr_num as orig_subr_num
    ,tb.subr_sw_on_date
    ,tb.cust_num
    ,tb.subr_num
    ,trunc(ta.seq) + 1 +(row_number() over (partition by tb.uniq_key order by tb.max_trx_date))*0.01 seq
    ,nvl(p.subr_stat_cd,'TX') as subr_stat_cd
    ,nvl(p.subr_sw_off_date,&rpt_e_date) as subr_sw_off_date
    ,ta.amort_period_mth
    ,ta.amort_expiry_date
    ,ta.serv_rev_comm
    ,tb.max_trx_date
    ,0 as ca_serv_rev_comm_amt
    ,0 as ca_amort_amt
    ,0 as ca_unamort_cf_amt
    ,0 as cab_unamort_bf_amt
    ,0 as cab_diff_unam_am_amt
    ,0 as cab_unamort_cf_amt
    ,0 as ttl_unamort_bf_amt
    ,0 as ttl_diff_comm_cm_amt
    ,0 as ttl_amort_amt
    ,0 as ttl_unamort_cf_amt
    ,ta.salesman
    ,ta.cust_name
    ,ta.act_month
    ,' ' as calc_remark
    ,' ' as calc_status
    ,sysdate as create_ts
    ,sysdate as refresh_ts
  from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004B_T tb
    left outer join ${etlvar::ADWDB}.subr_info_hist p
        on tb.cust_num = p.cust_num
    and tb.subr_num = p.subr_num
    and &rpt_e_date between p.start_date and p.end_date
  , ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004A_T ta
  where tb.uniq_key = ta.uniq_key;
commit;

prompt '[Calculate the last mth case amt ]';
update ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T t
set     (t.cab_unamort_bf_amt,t.cab_diff_unam_am_amt) = (
                select r1.ttl_unamort_cf_amt
                        ----- Ussing abs to handle negetive amt amortise .
                        ,least(abs(r1.ttl_unamort_cf_amt),abs(r1.ttl_amort_amt))
                          * decode(r1.ttl_amort_amt,0,0,(r1.ttl_amort_amt / abs(r1.ttl_amort_amt)))
                from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004A_T r1
                where t.uniq_key = r1.uniq_key
        )
where (t.uniq_key,t.seq) in (
        select r.uniq_key,max(r.seq)
        from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T r
        group by r.uniq_key
);
commit;

prompt '[Calculate the last mth case amt for cab_unamort_cf_amt]';

----- only update the amount in new case -----
update ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T t
set     t.cab_unamort_cf_amt =  t.cab_unamort_bf_amt
                                - least(abs(t.cab_unamort_bf_amt),abs(t.cab_diff_unam_am_amt))
                                *decode(t.cab_unamort_bf_amt,0,0,(t.cab_unamort_bf_amt/abs(t.cab_unamort_bf_amt)))
where (t.uniq_key,t.seq) in (
        select r.uniq_key,max(r.seq)
        from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T r
        group by r.uniq_key
);
commit;

prompt '[Preparing the end case ]';
----- Preparing the End case -------
update ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T t
set calc_status = 'END_CASE'
   ,calc_remark = case when t.subr_stat_cd in ( 'TX','SU')
                  then t.calc_remark ||';End case by Subr TX SU'
                  when abs(t.cab_unamort_cf_amt) < 1
                  then t.calc_remark ||';End case by abs(cab_Unamort_cf_amt) < 1'
                  when trunc(t.amort_expiry_date,'MM') = &rpt_s_date
                  then t.calc_remark ||';End case by expiry_date end'
                  when t.amort_period_mth < 4
                  then t.calc_remark ||';End by period less than 4'
                  end
where ( t.subr_stat_cd in('TX','SU')
        or abs(t.cab_unamort_cf_amt) < 1
        or trunc(t.amort_expiry_date,'MM') = &rpt_s_date
-----UPD20190510
        or t.amort_period_mth<4 )
and (t.uniq_key,t.seq) in (
        select r.uniq_key,max(r.seq)
        from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T r
        group by r.uniq_key
);
commit;

prompt '[Override the end case amount ]';
----- Override the End case amount -----
update ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T t
set t.cab_diff_unam_am_amt = t.cab_unamort_bf_amt
    ,t.cab_unamort_cf_amt = 0
where  calc_status ='END_CASE';

prompt '[Override the all case amount for total amount]';
----- Calculate the total amount issue -----
update ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T t
set     t.ttl_unamort_bf_amt = t.cab_unamort_bf_amt
        ,t.ttl_diff_comm_cm_amt = t.ca_serv_rev_comm_amt
        ,t.ttl_amort_amt = t.cab_diff_unam_am_amt + t.ca_amort_amt
        ----ttl_unamort_bf_amt + ttl_diff_comm_cm_amt - ttl_amort_amt----
        ,t.ttl_unamort_cf_amt  = t.cab_unamort_bf_amt + t.ca_serv_rev_comm_amt - (t.cab_diff_unam_am_amt + t.ca_amort_amt)
where (t.uniq_key,t.seq) in (
        select r.uniq_key,max(r.seq)
        from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T r
        group by r.uniq_key
);
commit;

prompt '[Preparing the final records for all amount ]';
insert into ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_005A_T
(
     rpt_mth
    ,uniq_key
    ,orig_cust_num
    ,orig_subr_num
    ,subr_sw_on_date
    ,subr_sw_off_date
    ,cust_num
    ,subr_num
    ,seq
    ,subr_stat_cd
    ,amort_period_mth
    ,amort_expiry_date
    ,serv_rev_comm
    ,trx_date
    ,ca_serv_rev_comm_amt
    ,ca_amort_amt
    ,ca_unamort_cf_amt
    ,cab_unamort_bf_amt
    ,cab_diff_unam_am_amt
    ,cab_unamort_cf_amt
    ,ttl_unamort_bf_amt
    ,ttl_diff_comm_cm_amt
    ,ttl_amort_amt
    ,ttl_unamort_cf_amt
    ,salesman
    ,cust_name
    ,act_month
    ,calc_remark
    ,calc_status
    ,create_ts
    ,refresh_ts
)
select
  rpt_mth
    ,uniq_key
    ,orig_cust_num
    ,orig_subr_num
    ,subr_sw_on_date
    ,subr_sw_off_date
    ,cust_num
    ,subr_num
    ,seq
    ,subr_stat_cd
    ,amort_period_mth
    ,amort_expiry_date
    ,serv_rev_comm
    ,trx_date
    ,ca_serv_rev_comm_amt
    ,ca_amort_amt
    ,ca_unamort_cf_amt
    ,cab_unamort_bf_amt
    ,cab_diff_unam_am_amt
    ,cab_unamort_cf_amt
    ,ttl_unamort_bf_amt
    ,ttl_diff_comm_cm_amt
    ,ttl_amort_amt
    ,ttl_unamort_cf_amt
    ,salesman
    ,cust_name
    ,act_month
    ,calc_remark
    ,calc_status
    ,create_ts
    ,refresh_ts
from  ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_003B_T
union all
select
  rpt_mth
    ,uniq_key
    ,orig_cust_num
    ,orig_subr_num
    ,subr_sw_on_date
    ,subr_sw_off_date
    ,cust_num
    ,subr_num
    ,seq
    ,subr_stat_cd
    ,amort_period_mth
    ,amort_expiry_date
    ,serv_rev_comm
    ,trx_date
    ,ca_serv_rev_comm_amt
    ,ca_amort_amt
    ,ca_unamort_cf_amt
    ,cab_unamort_bf_amt
    ,cab_diff_unam_am_amt
    ,cab_unamort_cf_amt
    ,ttl_unamort_bf_amt
    ,ttl_diff_comm_cm_amt
    ,ttl_amort_amt
    ,ttl_unamort_cf_amt
    ,salesman
    ,cust_name
    ,act_month
    ,calc_remark
    ,calc_status
    ,create_ts
    ,refresh_ts
from  ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_004C_T;
commit;

----Keep for uat ----
insert into ${etlvar::ADWDB}.BM_CAP_AMORT_RPT_H
select * from ${etlvar::TMPDB}.B_BM_CAP_AMORT_RPT_005A_T;
commit;




ENDOFINPUT

    close(SQLPLUS);
    my $RET_CODE = $? >> 8;
    if ($RET_CODE != 0){
        return 1;
    }else{
        return 0;
    }
}




#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_cust_info0010.pl adw_b_cust_info_20051010.dir\n");
    exit(1);
}




#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);
etlvar::genFirstDayOfMonth($etlvar::TXDATE);
my $ret = runSQLPLUS();
my $post = etlvar::postProcess();

exit($ret);