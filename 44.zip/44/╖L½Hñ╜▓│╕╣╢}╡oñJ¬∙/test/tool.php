<?php
class  WeChat {
	private  $_appid;
	private  $_appsecret;

	public  function __construct($_appid, $_appsecret){
		$this->appid = $_appid;
		$this->appsecret = $_appsecret;
	}

	public function _request($curl, $https = true, $method = "GET", $data = null, $type = null){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $curl);
		curl_setopt($ch, CURLOPT_HEADER, false );
		if($type == "JSON"){  
		    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if($https){
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, true);
		}
		if($method == "POST"){
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}

		$content = curl_exec($ch);
		curl_close($ch);
		return $content;
	} 
	
	public function _getAccessToken(){
		$file = 'saestor://tmp/accesstoken';
		if(file_exists($file)){
			$content = file_get_contents($file);
			$content = json_decode($content);
			if(time() - filemtime($file) < $content->expires_in)
			    return $content->access_token;
		}
		
		$curl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$this->appid.'&secret='.$this->appsecret;
		$content = $this->_request($curl);
		
		file_put_contents($file, $content);
		$content = json_decode($content);
		
		return $content->access_token; 
	}
    
    public function _getOpenidList(){
		$curl = "https://api.weixin.qq.com/cgi-bin/user/get?access_token=".$this->_getAccessToken()."&next_openid="; 
		$content = $this->_request($curl);
		$info = json_decode($content, true);
		return $info;
		
	}	
}

?>