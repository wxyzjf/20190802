<?php
    require_once 'tool.php';
	
	class SendMessage {
		private  $_content;
		private  $_openid;

		public  function __construct($_content, $_openid){
			$this->content = $_content;
			$this->openid = $_openid;
		}    
		  
	 
		function _sendMsgAll($content){
			$wechat = new WeChat($appid, $appsecret) ;
			$access_token = $wechat->_getAccessToken();
			$curl = "https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token=".$access_token;
			$dataArray = array(
							'filter' => array('is_to_all' => true,
                                              'tag_id'=>'',),
							'text' => array('content' => $content,),
							'msgtype' => 'text', 
						 );
			$postJson = json_encode($dataArray);
			$result = $wechat->_request($curl, true, 'POST', $postJson, 'JSON'); 
			return $result
		}

		function _sendMsgByOpenid($openid, $content){
			$wechat = new WeChat($appid, $appsecret) ;
			$access_token = $wechat->_getAccessToken();
			$curl = "https://api.weixin.qq.com/cgi-bin/message/mass/send?access_token=".$access_token;
			$dataArray = array(
							'touser' => $openid,
							'text' => array('content' => $content),
							'msgtype' => 'text', 
						 );
			$postJson = json_encode($dataArray);
			$result = $wechat->_request($curl, true, 'POST', $postJson, 'JSON'); 
			return $result
		} 
		
	}

	$openid = $_POST["openid"];
	$msgContent = $_POST["content"]; 
	$sendMessage = new SendMessage($openid, $msgContent); 
	if(empty($openid)){
		$result = $sendMessage->_sendMsgAll($msgContent)
	}else{
		$result = $sendMessage->_sendMsgByOpenid($msgContent)
	}  
	echo $result;

?>
