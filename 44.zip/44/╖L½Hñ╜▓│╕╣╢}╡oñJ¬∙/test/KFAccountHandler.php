<?php
class  WeChat {
    private  $_appid;
    private  $_appsecret;

    public  function __construct($_appid, $_appsecret){
        $this->appid = $_appid;
        $this->appsecret = $_appsecret;
    }

    public function _request($curl, $https = true, $method = "GET",  $data = null){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $curl);
        curl_setopt($ch, CURLOPT_HEADER, false );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if($https){
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, true);
        }
        if($method == "POST"){
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }

        $content = curl_exec($ch);
        curl_close($ch);
        return $content;
    } 
    
    public function _getAccessToken(){
        $file = 'saestor://tmp/accesstoken';
        if(file_exists($file)){
            $content = file_get_contents($file);
            $content = json_decode($content);
            if(time() - filemtime($file) < $content->expires_in)
                return $content->access_token;
        }
        
        $curl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$this->appid.'&secret='.$this->appsecret;
        $content=$this->_request($curl);
        file_put_contents($file, $content);
        $content = json_decode($content);
        return $content->access_token; 
    }  

    public function _getKFList(){
        $curl = "https://api.weixin.qq.com/cgi-bin/customservice/getkflist?access_token=".$this->_getAccessToken();
        $content = $this->_request($curl);
        return $content;
    }

    public function _getOnlineKFList(){
        $curl = "https://api.weixin.qq.com/cgi-bin/customservice/getonlinekflist?access_token=".$this->_getAccessToken();
        $content = $this->_request($curl);
        return $content;
    }

    public function _addKFAccount(){
        $data = '{ 
                    "kf_account": "test1@gz_eva_test", 
                    "nickname"  : "�ͷ�1"
                 }';
        
        $curl = "https://api.weixin.qq.com/customservice/kfaccount/add?access_token=".$this->_getAccessToken();
        $content = $this->_request($curl, true, "POST", $data);
        return $content;
    }

    public function _inviteKFAccount(){
        $data = '{
                   "kf_account": "test1@gz_eva_test",  
                   "invite_wx" : "evawu_"
                 }';
        $curl = "https://api.weixin.qq.com/customservice/kfaccount/inviteworker?access_token=".$this->_getAccessToken();
        $content = $this->_request($curl, true, "POST", $data);
        return $content;
    }

    public function _updateKFAccount(){
        $data = '{
                   "kf_account": "test1@gz_eva_test",  
                   "nickname" : "�ͷ�һ"
                 }';
        $curl = "https://api.weixin.qq.com/customservice/kfaccount/update?access_token=".$this->_getAccessToken();
        $content = $this->_request($curl, true, "POST", $data);
        return $content;
    }

    public function _deleteKFAccount($kfAccount){
        $curl = "https://api.weixin.qq.com/customservice/kfaccount/del?access_token=".$this->_getAccessToken()."&kf_account=".$kfAccount;
        $content = $this->_request($curl);
        return $content;
    }
} 

$wechat = new  WeChat("wx25530566fd4677a7", "cc79b62b190528c8399a4c4e97210ae2");
echo  $wechat->_addKFAccount();
