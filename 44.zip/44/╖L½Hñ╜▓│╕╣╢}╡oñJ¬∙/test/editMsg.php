<?php
    require_once 'getOpenidList.php';
	$wechat = new WeChat("wx25530566fd4677a7", "cc79b62b190528c8399a4c4e97210ae2");
    $info = $wechat->_getOpenidList();
    $openidList = $info['data']['openid'];
?>
<html>
    <head>
       <script>
       function chgSendType(){
           var openids = document.getElementsByName('openid[]');
           for(var i = 0; i < openids.length; i++){
               openids[i].checked = false;
           }
       }
       </script>
    </head>
    <body>
	    <H4>發送信息</H4>
        <form action="sendUserMsg.php" method="POST">  
        <table>
            <col width="120px">
            <col width="320px">
            <tr>
                <td colspan="2">
                <input type="radio" name="sendType" checked onclick="chgSendType()"/>所有人
                </td>
            </tr>
            <tr> 
                <td><input type="radio" name="sendType"/>用戶列表</td>
                <td>
<?php
                foreach($userOpenIdList as $openid){
                    echo "<input type='checkbox' name='openid[]' value='".$openid ."'/>" .$openid. "<br>";
                }
?>
                </td>
             </tr>
             <tr>
                <td>發送內容</td>
                <td>
                <textarea id="content" name="content" style="width:300px; height:100px" maxlength="490"></textarea>
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="2">
                <input type="submit" value="發送" style="width:60px"/>
                </td>
            </tr>
        </table> 
        </form>  
    </body>
</html>
