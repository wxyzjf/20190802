<?php
class  WeChat {
	private  $_appid;
	private  $_appsecret;

	public function __construct($_appid, $_appsecret){
		$this->appid = $_appid;
		$this->appsecret = $_appsecret;
	}

	public function _request($curl, $https = true, $method = "GET",  $data = null){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $curl);
		curl_setopt($ch, CURLOPT_HEADER, false );
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if($https){
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, true);
		}
		if($method == "POST"){
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}

		$content = curl_exec($ch);
		curl_close($ch);
		return $content;
	} 
	
	public function _getAccessToken(){
		$file = 'saestor://tmp/accesstoken';
		if(file_exists($file)){
			$content = file_get_contents($file);
			$content = json_decode($content);
			if(time() - filemtime($file) < $content->expires_in)
			    return $content->access_token;
		}
		
		$curl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$this->appid.'&secret='.$this->appsecret;
		$content=$this->_request($curl);
		file_put_contents($file, $content);
		$content = json_decode($content);
		return $content->access_token; 
	}  

	public function _getTicket($sceneid, $type="temp", $expire_seconds=604800){
		if($type == "temp"){
			$data = '{"expire_seconds": %s, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": %s}}}';
			$data = sprintf($data, $expire_seconds, $sceneid);
		}else{
			$data = '{"action_name": "QR_LIMIT_SCENE", "action_info": {"scene":{"scene_id": %s}}}';
			$data = sprintf($data, $sceneid);
		}
		
		$curl = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$this->_getAccessToken();
		$content = $this->_request($curl, true, "POST", $data);
		$content = json_decode($content);
		return $content->ticket;
	}

	public function _getQRCode($sceneid, $type="temp", $expire_seconds = 604800){
		$ticket = $this->_getTicket($sceneid, $type, $expire_seconds);
		$curl = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".urlencode($ticket); 
		$content = $this->_request($curl);
		return $content;
	}
	
} 

$wechat = new  WeChat("wx25530566fd4677a7", "cc79b62b190528c8399a4c4e97210ae2") ;
//echo  $wechat->_getTicket('1');
header('Content-type:image/jpeg');
echo $wechat->_getQRCode('10'); 

?>